package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FriedFish_Recipe extends DesiFood_Template implements ActionListener {

    public FriedFish_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Fried Fish.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Fried-Fishi-Cover.jpg"));

        //Heading...............................
        heading.setText("Fried Fish");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("4 fish steaks or fillets");
        //Ingredients2
        text2.setText(" 4 teaspoons turmeric powder");
        //Ingredients3
        text3.setText("2 teaspoons chilli powder");
        //Ingredients4
        text4.setText("Salt to taste");
        //Ingredients5
        text5.setText("Vinegar");

        //Steps to prepare Dish..................
        Text_area.setText("\n1.Wash and dry the fish. Mix turmeric, chilli powder and salt with a " +
                "\nlittle vinegar to make a paste. \n" +
                "\n2.Rub the paste into both sides of the fish.\n " +
                "\n3.Heat a little oil in a frying pan and fry the fish until cooked.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n1.Wash and dry the fish. Mix turmeric, chilli powder and salt with a " +
                    "\nlittle vinegar to make a paste. \n" +
                    "\n2.Rub the paste into both sides of the fish.\n " +
                    "\n3.Heat a little oil in a frying pan and fry the fish until cooked.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Oil for frying");
            //Ingredients2
            text2.setText("");
            //Ingredients3
            text3.setText("");
            //Ingredients4
            text4.setText("");
            //Ingredients5
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1.Wash and dry the fish. Mix turmeric, chilli powder and salt with a " +
                    "\nlittle vinegar to make a paste. \n" +
                    "\n2.Rub the paste into both sides of the fish.\n " +
                    "\n3.Heat a little oil in a frying pan and fry the fish until cooked.");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("4 fish steaks or fillets");
            //Ingredients2
            text2.setText(" 4 teaspoons turmeric powder");
            //Ingredients3
            text3.setText("2 teaspoons chilli powder");
            //Ingredients4
            text4.setText("Salt to taste");
            //Ingredients5
            text5.setText("Vinegar");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
