package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cheese_Burger_Recipe extends FastFoodTemplate implements ActionListener {

    public Cheese_Burger_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\CheeseBurger.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\CheeseBurger -Cover.jpg"));

        //Heading...............................
        heading.setText("Cheese Burger");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("¼ cup Mayonnaise");
        //Ingredients2
        text2.setText("1 Tbsp. Sriracha Sauce");
        //Ingredients3
        text3.setText("2 lbs. Ground sirloin");
        //Ingredients4
        text4.setText("4 buns, toasted");
        //Ingredients5
        text5.setText("1 tsp. Kosher salt");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) In a medium bowl, combine mayonnaise and Sriracha sauce. Cover" +
                "\nand refrigerate until ready to serve the burgers." +
                "\n\n2) Place the ground sirloin in a large bowl. Add the Cajun \nseasoning, salt and pepper and mix until " +
                "incorporated. Divide and form the meat \ninto 4 equal patties, being " +
                "sure not to compress the meat too much. \nPlace a thumbprint size indention in the" +
                "top center of each burger\n and then transfer to a plate or tray and let sit at room temperature." +
                "\n\n3) Pre-heat grill on medium heat. Once hot, place burgers on\n grill over direct heat and grill for 5 minutes" +
                " Then flip and cook for an \nadditional 5-7 minutes, until cooked to desired doneness." );

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\n4) Place cheese on burger right before you take the burgers\n off the grill and close the lid so that the" +
                    "cheese can melt. Transfer burgers \nto a clean plate, cover loosely with foil and let rest for 5 minutes." +
                    "\n\n5) Assemble the burgers by placing the lettuce directly on the\n bottom bun. Then add" +
                    "tomato and onion on top of the lettuce if desired.\n Place the burger on the lettuce" +
                    "tomato and onion, and then top \nthe burger with Sriracha Mayo sauce and pickled jalapeños.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("½ tsp. Cajun seasoning");
            //Ingredients7
            text2.setText("½ tsp. Fresh ground black pepper");
            //Ingredients8
            text3.setText("¼ cup pickled Jalapeños");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);
        }
        if(e.getSource()==Previous_btn){
            //Steps to prepare Dish..................
            Text_area.setText("\n1) In a medium bowl, combine mayonnaise and Sriracha sauce. Cover" +
                    "\nand refrigerate until ready to serve the burgers." +
                    "\n\n2) Place the ground sirloin in a large bowl. Add the Cajun \nseasoning, salt and pepper and mix until " +
                    "incorporated. Divide and form the meat \ninto 4 equal patties, being " +
                    "sure not to compress the meat too much. \nPlace a thumbprint size indention in the" +
                    "top center of each burger\n and then transfer to a plate or tray and let sit at room temperature." +
                    "\n\n3) Pre-heat grill on medium heat. Once hot, place burgers on\n grill over direct heat and grill for 5 minutes" +
                    " Then flip and cook for an \nadditional 5-7 minutes, until cooked to desired doneness." );

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("¼ cup Mayonnaise");
            //Ingredients2
            text2.setText("1 Tbsp. Sriracha Sauce");
            //Ingredients3
            text3.setText("2 lbs. Ground sirloin");
            //Ingredients4
            text4.setText("4 buns, toasted");
            //Ingredients5
            text5.setText("1 tsp. Kosher salt");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}
