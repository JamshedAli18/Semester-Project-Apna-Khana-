package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Saag_Recipe extends DesiFood_Template implements ActionListener {

    public Saag_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Saag.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Saag-Cover.jpg"));

        //Heading...............................
        heading.setText("Saag");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText(" Mustard (sarson) leaves, cleaned, washed");
        //Ingredients2
        text2.setText("Spinach (palak), chopped 500 gm");
        //Ingredients3
        text3.setText("Turnip (shalgam), chopped 1");
        //Ingredients4
        text4.setText("Dill (soy saag), chopped 200 gm");
        //Ingredients5
        text5.setText("Radish (mooli) leaves, chopped 4-5");

        //Steps to prepare Dish..................
        Text_area.setText("\n1. Boil 1 cup water in a pan, add the mustard leaves, spinach, turnip," +
                "\n dill, and radish leaves.\n" +
                "\n2. Cook for 30 minutes till the water evaporates.\n" +
                "\n3. Remove and keep aside to cool.\n" +
                "\n4. Dry roast the maize flour for a few minutes till a good fragrance emanates.\n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText( "\n5. Blend the leaves in a blender.\n" +
                    "\n6. Transfer the contents in a pan, add the maize flour and salt,\n" +
                    "cook till it begins to leave the sides of the pan.\n" +
                    "\n7. Heat the ghee in another pan, add the asafoetida, ginger, garlic, " +
                    "and green chillies.\n" +
                    "\n8. Saute for a while. Add this to the green mixture, mix well.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Maize flour (makkai ka atta) 1 tbsp");
            //Ingredients2
            text2.setText("Ingredient eight");
            //Ingredients3
            text3.setText("Ghee 3 tbsp");
            //Ingredients4
            text4.setText("Asafoetida (hing) a pinch");
            //Ingredients5
            text5.setText("Ginger (adrak), julienned 100 gm");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1. Boil 1 cup water in a pan, add the mustard leaves, spinach, turnip," +
                    "\n dill, and radish leaves.\n" +
                    "\n2. Cook for 30 minutes till the water evaporates.\n" +
                    "\n3. Remove and keep aside to cool.\n" +
                    "\n4. Dry roast the maize flour for a few minutes till a good fragrance emanates.\n");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText(" Mustard (sarson) leaves, cleaned, washed");
            //Ingredients2
            text2.setText("Spinach (palak), chopped 500 gm");
            //Ingredients3
            text3.setText("Turnip (shalgam), chopped 1");
            //Ingredients4
            text4.setText("Dill (soy saag), chopped 200 gm");
            //Ingredients5
            text5.setText("Radish (mooli) leaves, chopped 4-5");
            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
