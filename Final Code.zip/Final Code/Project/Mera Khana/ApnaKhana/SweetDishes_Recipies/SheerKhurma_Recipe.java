package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SheerKhurma_Recipe extends SweetDished_Template implements ActionListener {

   public SheerKhurma_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\SheerKhurma.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\SheerKhurma-Cover.jpg"));

        //Heading...............................
        heading.setText("Sheer Khurma");

       //Ingredients sections
       text.setText("Ingredients");
       //Ingredients1
       text1.setText("Olper’s Full Cream Milk 1 Litre");
       //Ingredients2
       text2.setText("Desi ghee (Clarified butter) 2 tbs");
       //Ingredients3
       text3.setText("Chuwaray (Dry dates) boiled & sliced 8-10");
       //Ingredients4
       text4.setText("Cashew nuts,Almonds,Pistachios sliced 2 tbs");
       //Ingredients5
       text5.setText("Kishmish (Raisins) washed 1 tbs");

        //Steps to prepare Dish..................
       Text_area.setText("1)  In a wok,add milk,bring it to boil & cook for 2-3 minutes until milk thickens.\n\n" +
               "2)  In frying pan,add clarified butter & let it melt.\n\n3)Add dry dates and mix well.\n\n" +
               "4)  Add cashew nuts,almonds,pistachios,raisins,mix well and fry for 2 minutes.\n\n" +
               "5)  Add fried nuts (reserve for later use),sugar,cardamom pods,mix well and cook\n " +
               "on medium flame for 4-5 minutes & keep mixing in between.\n\n" +
               "6)  In frying pan,add clarified butter & let it melt.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

       //Previous Frame Button.........................
       PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("7)  Add vermicelli and fry for 2 minutes.\n\n" +
                    "8)  Add fried vermicelli,mix well and cook for 6-8 minutes.\n\n" +
                    "9)  Add kewra water,mix well & cook untuil desired consistency.\n\n" +
                    "10)  Garnish with fried nuts,dried rose petals & serve!");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Sugar ½ Cup or to taste");
            //Ingredients7
            text2.setText("Elaichi ke daane ");
            //Ingredients8
            text3.setText("Desi ghee");
            //Ingredients9
            text4.setText("Sawaiyan (Vermicelli)");
            //Ingredients10
            text5.setText("Kewra water ½ tsp and rose petals");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn) {

            Text_area.setText("1)  In a wok,add milk,bring it to boil & cook for 2-3 minutes until milk thickens.\n\n" +
                    "2)  In frying pan,add clarified butter & let it melt.\n\n3)Add dry dates and mix well.\n\n" +
                    "4)  Add cashew nuts,almonds,pistachios,raisins,mix well and fry for 2 minutes.\n\n" +
                    "5)  Add fried nuts (reserve for later use),sugar,cardamom pods,mix well and cook\n " +
                    "on medium flame for 4-5 minutes & keep mixing in between.\n\n" +
                    "6)  In frying pan,add clarified butter & let it melt.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Olper’s Full Cream Milk 1 Litre");
            //Ingredients2
            text2.setText("Desi ghee (Clarified butter) 2 tbs");
            //Ingredients3
            text3.setText("Chuwaray (Dry dates) boiled & sliced 8-10");
            //Ingredients4
            text4.setText("Cashew nuts,Almonds,Pistachios sliced 2 tbs");
            //Ingredients5
            text5.setText("Kishmish (Raisins) washed 1 tbs");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();

        }
    }
}
