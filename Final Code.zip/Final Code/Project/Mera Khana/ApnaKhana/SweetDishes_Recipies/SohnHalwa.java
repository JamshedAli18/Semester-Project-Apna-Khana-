package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SohnHalwa extends SweetDished_Template implements ActionListener {

    public SohnHalwa(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\SohnHalwa.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\SohnHalwa-Cover.jpg"));

        //Heading...............................
        heading.setText("Sohan Halwa");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 liter milk");
        //Ingredients2
        text2.setText("1/2 tsp. lemon salt");
        //Ingredients3
        text3.setText("6 tbsp. white flour");
        //Ingredients4
        text4.setText("2 tbsp. sprouted wheat flour");
        //Ingredients5
        text5.setText("1 cup sugar");

        //Steps to prepare Dish..................
        Text_area.setText("1)  In a deep pan boil milk and add white flour, Sprouted Wheat flour and then\n lemon salt. Stir lightly. Let it boil for 5 minutes.\n\n" +
                "2)   Now Paneer will separate and cook on low heat, constantly.\n\n" +
                "3)   When paneer mixture is reduced to half, gradually put sugar, keep stirring\n " +
                "slowly, otherwise lumps may form. Now a smooth mixture will be formed.\n\n" +
                "4)  When it is thick, add ghee & cook. After 20-25 minutes, it will not stick to the\n" +
                " pan & it will leave the sides and ghee.\n\n5)  Mix almond and walnut & take out & spread it in " +
                "a dish evenly & cut into ");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){
            Text_area.setText("the desired shapes like diamond or square pieces.\n\n6)  Garnish with pistachios & almonds.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("4 tbsp. pure ghee");
            //Ingredients7
            text2.setText("4-5 green cardamoms");
            //Ingredients8
            text3.setText("Almonds and walnuts");
            //Ingredients9
            text4.setText("Almonds, chopped");
            //Ingredients10
            text5.setText("Pistachios chopped");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){
            Text_area.setText("1)  In a deep pan boil milk and add white flour, Sprouted Wheat flour and then\n lemon salt. Stir lightly. Let it boil for 5 minutes.\n\n" +
                    "2)   Now Paneer will separate and cook on low heat, constantly.\n\n" +
                    "3)   When paneer mixture is reduced to half, gradually put sugar, keep stirring\n " +
                    "slowly, otherwise lumps may form. Now a smooth mixture will be formed.\n\n" +
                    "4)  When it is thick, add ghee & cook. After 20-25 minutes, it will not stick to the\n" +
                    " pan & it will leave the sides and ghee.\n\n5)  Mix almond and walnut & take out & spread it in " +
                    "a dish evenly & cut into ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 liter milk");
            //Ingredients2
            text2.setText("1/2 tsp. lemon salt");
            //Ingredients3
            text3.setText("6 tbsp. white flour");
            //Ingredients4
            text4.setText("2 tbsp. sprouted wheat flour");
            //Ingredients5
            text5.setText("1 cup sugar");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {
            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();
        }
    }
}
