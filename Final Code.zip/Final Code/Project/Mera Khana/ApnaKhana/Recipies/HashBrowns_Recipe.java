package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HashBrowns_Recipe extends FastFoodTemplate implements ActionListener {

    public HashBrowns_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Hashbrowns.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Hashbrowns-Cover.jpg"));

        //Heading...............................
        heading.setText("Hash Browns");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("15 oz. bag of frozen shredded hash browns");
        //Ingredients2
        text2.setText("1 cup Sharp cheddar cheese");
        //Ingredients3
        text3.setText("1 tablespoon olive oil");
        //Ingredients4
        text4.setText("8 medium eggs");
        //Ingredients5
        text5.setText("Salt and pepper to taste");

        //Steps to prepare Dish..................
        //Steps to prepare Dish..................
        Text_area.setText("\n1) Mix the hash browns, cheddar cheese, olive oil" +
                "\n and salt and pepper to taste in a mixing bowl.\n" +
                "\n\n2) Grease the muffin pan and divide hash brown mixture. Use " +
                "\n your fingers to pack them tightly and shape them into nests" +
                "\n\n3) Bake at 425°F (220°C) for 15 minutes" +
                "\n\n4) Remove the pan from the oven and crack a medium egg into " +
                "\n muffin cup on top of the hash browns. Season with salt and pepper to taste. ");


        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\nTop with crumbled bacon and 1 tablespoon cheese." +
                    "\n\n5) Reduce the temperature and bake at 350°F (175°C) until the egg"+
                    "\n whites are cooked, about 15 minutes. If you like your egg yolks over medium, " +
                    "\n increase cook time to 20 minutes." +
                    "\n\n6) Remove from the oven and garnish with parsley. Let the egg nexts" +
                    "\nsit for a couple of minutes so that it can set. Then gently slide a knife along the edges" +
                    "\nand use a fork to lift them out of the pan.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("2 slices cooked bacon");
            //Ingredients7
            text2.setText("1 tablespoon Sharp cheddar cheese");
            //Ingredients8
            text3.setText("1/2 tablespoon parsley");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Mix the hash browns, cheddar cheese, olive oil" +
                    "\n and salt and pepper to taste in a mixing bowl.\n" +
                    "\n\n2) Grease the muffin pan and divide hash brown mixture. Use " +
                    "\n your fingers to pack them tightly and shape them into nests" +
                    "\n\n3) Bake at 425°F (220°C) for 15 minutes" +
                    "\n\n4) Remove the pan from the oven and crack a medium egg into " +
                    "\n muffin cup on top of the hash browns. Season with salt and pepper to taste. ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("15 oz. bag of frozen shredded hash browns");
            //Ingredients2
            text2.setText("1 cup Sharp cheddar cheese");
            //Ingredients3
            text3.setText("1 tablespoon olive oil");
            //Ingredients4
            text4.setText("8 medium eggs");
            //Ingredients5
            text5.setText("Salt and pepper to taste");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}
