package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pasta_Recipe extends FastFoodTemplate implements ActionListener {

    public Pasta_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Pasta.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Pasta-Cover.jpg"));

        //Heading...............................
        heading.setText("Pasta");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 lb lean ground beef");
        //Ingredients2
        text2.setText("2 1/2 Tbsp taco seasoning");
        //Ingredients3
        text3.setText("2 cups salsa");
        //Ingredients4
        text4.setText("16 oz elbows or Rotini pasta");
        //Ingredients5
        text5.setText("4 cups beef or chicken broth");

        //Steps to prepare Dish..................
        Text_area.setText("1) Turn the Instant Pot to Sauté mode. When display reads Hot, add the ground" +
                "\nmeat and saute until mostly browned." +
                "\n\n2) Sprinkle the taco seasoning on top of the beef and stir and finish browning \n the meat" +
                "\n\n3) Add the salsa, broth, and pasta to the pot and stir." +
                "\n\n4) Lock the lid in place and set the valve to the SEALING position. \nPress Pressure Cook" +
                "/Manual and set the cook time for half of the time on the \npasta box. (Typically 4-5 minutes)." +
                "\n\n5) When the cook time is up slowly move the valve to the  ");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\nventing position to Quick Release the pressure." +
                    "\n\n6) When the pin drops carefully remove the lid and stir." +
                    "\n\n7) Add the cheese and stir again." +
                    "\n\n   Serve warm and top with extra cheese, sour cream, salsa, and/or cilantro");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("2 cups Monterey Jack and Cheddar");
            //Ingredients7
            text2.setText("");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("1) Turn the Instant Pot to Sauté mode. When display reads Hot, add the ground" +
                    "\nmeat and saute until mostly browned." +
                    "\n\n2) Sprinkle the taco seasoning on top of the beef and stir and finish browning \n the meat" +
                    "\n\n3) Add the salsa, broth, and pasta to the pot and stir." +
                    "\n\n4) Lock the lid in place and set the valve to the SEALING position. \nPress Pressure Cook" +
                    "/Manual and set the cook time for half of the time on the \npasta box. (Typically 4-5 minutes)." +
                    "\n\n5) When the cook time is up slowly move the valve to the  ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 lb lean ground beef");
            //Ingredients2
            text2.setText("2 1/2 Tbsp taco seasoning");
            //Ingredients3
            text3.setText("2 cups salsa");
            //Ingredients4
            text4.setText("16 oz elbows or Rotini pasta");
            //Ingredients5
            text5.setText("4 cups beef or chicken broth");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}
