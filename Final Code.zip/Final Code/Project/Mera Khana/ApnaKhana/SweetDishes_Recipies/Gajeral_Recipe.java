package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Gajeral_Recipe extends SweetDished_Template implements ActionListener {

    public Gajeral_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Gajreela.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Gajreela-Cover.jpg"));

        //Heading...............................
        heading.setText("Gajrela");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Doodh (Milk) Fresh & boiled 1 & ½ liters");
        //Ingredients2
        text2.setText("Chawal (Rice) Soaked ¼ Cup");
        //Ingredients3
        text3.setText("Gajar (Carrots) Grated 300 gm");
        //Ingredients4
        text4.setText("Elaichi powder (Cardamom powder) ½ tsp");
        //Ingredients5
        text5.setText("Cheeni (Sugar) ½ cup");

        //Steps to prepare Dish..................
        Text_area.setText("\n\n1)  Rinse, peel and grate the carrots.\n\n" +
                "2)  In pot,heat milk,add rice (crushed) and carrots, mix well.\n\n3)  " +
                "Add cardamom powder,cook on low flame for 15-20 minutes and keep\n  " +
                "  stirring in between.\n\n4)  Now add sugar,mix well until sugar is dissolved.\n\n5) " +
                " Cook until milk is reduced and thickened.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){
            Text_area.setText("\n\n6)  Add pistachio and almonds, give it a good mix.\n\n7)  " +
                    "Serve hot or cold. ");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Pista (Pistachio) chopped 2-3 tbs");
            //Ingredients7
            text2.setText("Badam (Almonds) Blanched & chopped 2-3 tbs");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n\n1)  Rinse, peel and grate the carrots.\n\n" +
                    "2)  In pot,heat milk,add rice (crushed) and carrots, mix well.\n\n" +
                    "3)  Add cardamom powder,cook on low flame for 15-20 minutes and keep\n    stirring in between." +
                    "\n\n4)  Now add sugar,mix well until sugar is dissolved.\n\n" +
                    "5)  Cook until milk is reduced and thickened.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Doodh (Milk) Fresh & boiled 1 & ½ liters");
            //Ingredients2
            text2.setText("Chawal (Rice) Soaked ¼ Cup");
            //Ingredients3
            text3.setText("Gajar (Carrots) Grated 300 gm");
            //Ingredients4
            text4.setText("Elaichi powder (Cardamom powder) ½ tsp");
            //Ingredients5
            text5.setText("Cheeni (Sugar) ½ cup");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();

        }
    }
}
