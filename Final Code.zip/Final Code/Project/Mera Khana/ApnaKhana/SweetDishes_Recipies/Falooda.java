package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Falooda extends SweetDished_Template implements ActionListener {

    public Falooda(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\Falooda.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Falooda-Cover.jpg"));

        //Heading...............................
        heading.setText("Falooda");

        //Ingredients sections
        text.setText("Ingredients");
        text1.setText("Doodh (Milk) 1 litre");
        text2.setText("Tetrapack cream 200 ml");
        text3.setText("Cheeni (Sugar) ¼ Cup or to taste");
        text4.setText("Vanilla essence ¼ tsp");
        text5.setText("Corn flour 1 & ½ tbs (optional)");

        //Steps to prepare Dish..................
        Text_area.setText("\n1)  Assemblings:\n* Corn flour ki seviyan (Corn flour vermicelli).\n* " +
                "Tukh malanga (Basil seeds).\n* Green and Red jelly.\n* Mix dry fruit crushed.\n* " +
                "Rabri (Thickened milk).\n* Vanilla ice cream.\n\n2)  In pot,add milk,tetrapack " +
                "cream,sugar and vanilla essence,whisk well.\n\n3) When comes to boil,dissolve " +
                "corn flour in water and add in it,mix well and");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\n\n cook until milk is thickened.Rabri (thickened milk) is ready and let it cool" +
                    "\n\n4)  In glass,add basil leaves and soak in water for 15-20 minutes.\n\n" +
                    "5)  Assembling:\n* In glass,add lal sharbat,corn flour vermicelli,basil seeds,green " +
                    "jelly,\n red jelly,mix dry fruits,rabri (thickened milk),vanilla ice cream and\n " +
                    "drizzle lal sharbat.\n* Ice cream faluda is ready.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Pani (Water) ¼ Cup");
            //Ingredients7
            text2.setText("Tukh malanga (basil seeds) 1 tbs or as required");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1)  Assemblings:\n* Corn flour ki seviyan (Corn flour vermicelli).\n*" +
                    " Tukh malanga (Basil seeds).\n* Green and Red jelly.\n* Mix dry fruit crushed.\n* " +
                    "Rabri (Thickened milk).\n* Vanilla ice cream.\n\n2)  In pot,add milk,tetrapack cream," +
                    "sugar and vanilla essence,whisk well.\n\n3) When comes to boil,dissolve corn flour " +
                    "in water and add in it,mix well and");

            //Ingredients sections
            text.setText("Ingredients");
            text1.setText("Doodh (Milk) 1 litre");
            text2.setText("Tetrapack cream 200 ml");
            text3.setText("Cheeni (Sugar) ¼ Cup or to taste");
            text4.setText("Vanilla essence ¼ tsp");
            text5.setText("Corn flour 1 & ½ tbs (optional)");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();

        }
    }
}

