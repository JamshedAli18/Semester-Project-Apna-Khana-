package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChickenKarhai_Recipe extends DesiFood_Template implements ActionListener {

    public ChickenKarhai_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Chicken Karhai.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Chicken-Karhai-Cover.jpg"));

        //Heading...............................
        heading.setText("Chicken Karhai");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1/2 kg chicken");
        //Ingredients2
        text2.setText("1/2 tomato");
        //Ingredients3
        text3.setText("1/4 oil");
        //Ingredients4
        text4.setText("2 tbsp dry red chili");
        //Ingredients5
        text5.setText("1 tsp sabit dhanya(grinded)");

        //Steps to prepare Dish..................
        Text_area.setText("\n1.First heat the oil, then add chicken and (bhoonlain)\n" +
                "\n2.Add ginger paste.\n" +
                "\n3.Now mix it for few mints, then cut and add tomato, Mix it.\n" +
                "\n4.Now add all the masalas and mix it well until the tomatos add mix and (galjayen).\n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5.At the end add yogurt and green chili.\n" +
                    "\n6.Let the water be dried out,and add butter and now low the"
                    +" temperature\n of your stove.\n" +
                    "\n7.Now slice the ginger and green chili and add it to you karahi.\n");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 tbsp mix garam masala(grinded)");
            //Ingredients2
            text2.setText("2 tbsp yogurt");
            //Ingredients3
            text3.setText("salt(as you like it)");
            //Ingredients4
            text4.setText("5 green chili large");
            //Ingredients5
            text5.setText("2 tbsp ginger paste");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1.First heat the oil, then add chicken and (bhoonlain)\n" +
                    "\n2.Add ginger paste.\n" +
                    "\n3.Now mix it for few mints, then cut and add tomato, Mix it.\n" +
                    "\n4.Now add all the masalas and mix it well until the tomatos add mix and (galjayen).\n");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1/2 kg chicken");
            //Ingredients2
            text2.setText("1/2 tomato");
            //Ingredients3
            text3.setText("1/4 oil");
            //Ingredients4
            text4.setText("2 tbsp dry red chili");
            //Ingredients5
            text5.setText("1 tsp sabit dhanya(grinded)");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
