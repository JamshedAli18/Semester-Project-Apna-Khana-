package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tenders_Recipe extends FastFoodTemplate implements ActionListener{

    public Tenders_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Tenders.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Tender-Cover.jpg"));

        //Heading...............................
        heading.setText("Tenders");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 lb chicken tenders");
        //Ingredients2
        text2.setText("1/2 cup Kentucky Kernel seasoned flour");
        //Ingredients3
        text3.setText("1 egg, beaten");
        //Ingredients4
        text4.setText("1 teaspoon water");
        //Ingredients5
        text5.setText("1/4 cup seasoned bread crumbs");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) Heat air fryer to 370°F." +
                "\n\n2) In a shallow bowl whisk the egg and water together and set aside." +
                "\n\n3) Place the Kentucky Kernel flour and breadcrumbs in 2 separate" +
                "\n shallow bowls."  +
                "\n\n4) Pat thawed chicken tenders dry. Then brush them" +
                "\n lightly with olive oil on both sides." +
                "\n\n5) Working in small batches of 3-4 tenders, dredge the chicken tenders in " +
                "\n the Kentucky Kernel seasoned flour, then dip them in the" );

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n egg mixture, then finally coat with seasoned bread crumbs." +
                    "\n\n6) Shake off excess breading and immediately place them in the air fryer." +
                    "\n\n7) Allow enough room between the tenders so that the air can flow adequately. Cook for" +
                    "\n 10 minutes, flip, and cook for an additional 10-15 minutes on " +
                    "\nother side or until internal temperature reaches 165 degrees F.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 lb chicken tenders");
            //Ingredients2
            text2.setText("1/2 cup Kentucky Kernel seasoned flour");
            //Ingredients3
            text3.setText("1 egg, beaten");
            //Ingredients4
            text4.setText("1 teaspoon water");
            //Ingredients5
            text5.setText("1/4 cup seasoned bread crumbs");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Heat air fryer to 370°F." +
                    "\n\n2) In a shallow bowl whisk the egg and water together and set aside." +
                    "\n\n3) Place the Kentucky Kernel flour and breadcrumbs in 2 separate" +
                    "\n shallow bowls."  +
                    "\n\n4) Pat thawed chicken tenders dry. Then brush them" +
                    "\n lightly with olive oil on both sides." +
                    "\n\n5) Working in small batches of 3-4 tenders, dredge the chicken tenders in " +
                    "\n the Kentucky Kernel seasoned flour, then dip them in the" );

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 lb chicken tenders");
            //Ingredients2
            text2.setText("1/2 cup Kentucky Kernel seasoned flour");
            //Ingredients3
            text3.setText("1 egg, beaten");
            //Ingredients4
            text4.setText("1 teaspoon water");
            //Ingredients5
            text5.setText("1/4 cup seasoned bread crumbs");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}
