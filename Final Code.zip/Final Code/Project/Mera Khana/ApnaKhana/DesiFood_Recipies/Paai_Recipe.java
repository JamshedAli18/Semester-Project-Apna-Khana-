package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Paai_Recipe extends DesiFood_Template implements ActionListener {

    public Paai_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Paai.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Paai-Cover.jpg"));

        //Heading...............................
        heading.setText("Paai");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Lamb legs (paya) – 4");
        //Ingredients2
        text2.setText("Onions – 4 Medium sized");
        //Ingredients3
        text3.setText("Tomatoes – 4 Medium sized");
        //Ingredients4
        text4.setText("Fresh grated coconut – 2 Tbsp");
        //Ingredients5
        text5.setText("Green Chillies – 5");

        //Steps to prepare Dish..................

        Text_area.setText("\n1. Take 2 onions and chop them finely. Take these finely chopped onion " +
                "\npieces into a plate and keep aside.\n" +
                "\n2. Grind the remaining 2 onions and keep this onion paste aside.\n" +
                "\n3. Now grind coriander leaves, green chillies and coconut grating. Again take " +
                "\nthis paste into separate plate.\n" +
                "\n4. Make tomato puree out of the tomatoes. Keep all these pastes, onion pieces" +
                "\n and tomato puree aside.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5. Place these leg pieces into cooker. Now add 1 liter water, turmeric\n "+
                    "\n powder and salt to it\n" +
                    "\n6. Remove the lid of the pressure cooker and pour this complete masala in the " +
                    "\npan into the pressure cooker.\n" +
                    "\n7. Next add the tomato puree to it and mix well.\n" +
                    "\n8. Allow it for cooking for about 2 minutes under low flame.\n" +
                    "\n9. Check the salt.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Red Chilli Powder – 2 Tsp");
            //Ingredients2
            text2.setText("Garam Masala – 1 Tsp");
            //Ingredients3
            text3.setText("Turmeric Powder – 1/4 Tsp");
            //Ingredients4
            text4.setText("Cinnamon – 2 Small sticks");
            //Ingredients5
            text5.setText("Bay Leaf – 1");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1. Take 2 onions and chop them finely. Take these finely chopped onion " +
                    "\npieces into a plate and keep aside.\n" +
                    "\n2. Grind the remaining 2 onions and keep this onion paste aside.\n" +
                    "\n3. Now grind coriander leaves, green chillies and coconut grating. Again take " +
                    "\nthis paste into separate plate.\n" +
                    "\n4. Make tomato puree out of the tomatoes. Keep all these pastes, onion pieces" +
                    "\n and tomato puree aside.");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Lamb legs (paya) – 4");
            //Ingredients2
            text2.setText("Onions – 4 Medium sized");
            //Ingredients3
            text3.setText("Tomatoes – 4 Medium sized");
            //Ingredients4
            text4.setText("Fresh grated coconut – 2 Tbsp");
            //Ingredients5
            text5.setText("Green Chillies – 5");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
