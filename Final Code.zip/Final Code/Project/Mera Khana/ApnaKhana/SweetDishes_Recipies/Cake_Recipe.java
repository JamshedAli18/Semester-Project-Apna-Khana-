package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Cake_Recipe extends SweetDished_Template implements ActionListener {

    public Cake_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\Cake.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Cake-Cover.jpg"));

        //Heading...............................
        heading.setText("Cake");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("250 gm all purpose flour");
        //Ingredients2
        text2.setText("4 beaten egg");
        //Ingredients3
        text3.setText("1 teaspoon baking powder");
        //Ingredients4
        text4.setText("250 gm powdered sugar");
        //Ingredients5
        text5.setText("2 tablespoon cocoa powder");

        //Steps to prepare Dish..................
        Text_area.setText("1)   Mix all the dry ingredients and pre-heat the oven." +
                "\nTo prepare this easy chocolate cake recipe, pre-heat the oven to 180°C.\n Meanwhile, " +
                "grease and line a 7-inch round cake tin with baking paper and\n butter. Now, sieve together the " +
                "flour, cocoa powder and baking powder.\n Keep the dry ingredients aside.\n\n2)   Mix wet " +
                "ingredients into dry ingredients and bake the cake batter. Take a\n glass bowl and mix " +
                "butter and sugar into it. Beat these ingredients till light and\n fluffy. Make sure that " +
                "the sugar has dissolved. Now, beat in the eggs, two at a\n time and allowing " +
                "at least two minutes gap between each addition. Lightly fold\n in the flour " +
                "into the mixture. Pour the batter into the prepared tin and bake for\n 35 to 40 minutes. ");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Next_btn) {
            //Directions....................
            Text_area.setText("3)  Tasty Chocolate Cake is ready!.Check if the cake is baked properly by inserting" +
                    "\n a toothpick into the centre. If it comes out clean, then the cake is done. " +
                    "Transfer the\n cake onto a wire rack and allow it to cool completely. Cover with your favourite" +
                    "\n toppings. Then slice and serve.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1 cup butter");
            //Ingredients7
            text2.setText("");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if (e.getSource() == Previous_btn) {

            Text_area.setText("1)   Mix all the dry ingredients and pre-heat the oven." +
                    "\nTo prepare this easy chocolate cake recipe, pre-heat the oven to 180°C.\n Meanwhile, " +
                    "grease and line a 7-inch round cake tin with baking paper and\n butter. Now, sieve together the " +
                    "flour, cocoa powder and baking powder.\n Keep the dry ingredients aside.\n\n2)   Mix wet " +
                    "ingredients into dry ingredients and bake the cake batter. Take a\n glass bowl and mix " +
                    "butter and sugar into it. Beat these ingredients till light and\n fluffy. Make sure that " +
                    "the sugar has dissolved. Now, beat in the eggs, two at a\n time and allowing " +
                    "at least two minutes gap between each addition. Lightly fold\n in the flour " +
                    "into the mixture. Pour the batter into the prepared tin and bake for\n 35 to 40 minutes. ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("250 gm all purpose flour");
            //Ingredients2
            text2.setText("4 beaten egg");
            //Ingredients3
            text3.setText("1 teaspoon baking powder");
            //Ingredients4
            text4.setText("250 gm powdered sugar");
            //Ingredients5
            text5.setText("2 tablespoon cocoa powder");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();

        }
    }
}


