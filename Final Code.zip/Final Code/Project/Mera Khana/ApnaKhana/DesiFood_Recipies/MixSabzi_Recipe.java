package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MixSabzi_Recipe extends DesiFood_Template implements ActionListener {

    public MixSabzi_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Mix Sabzi.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Mix-sabzi-Cover.jpg"));

        //Heading...............................
        heading.setText("Mix Sabzi");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Mix Vegetables ½ kg");
        //Ingredients2
        text2.setText("Tomatoes (chopped) 2");
        //Ingredients3
        text3.setText("Potatoes (cubed) 1 cup");
        //Ingredients4
        text4.setText("Onion (chopped) 1");
        //Ingredients5
        text5.setText("Ginger Garlic Paste 2 tbsp");

        //Steps to prepare Dish..................
        Text_area.setText("1- Take some oil in the pan and sauté ginger garlic paste and 1 chopped onion " +
                "\nfor 3-4 minutes. Add in 2 chopped tomatoes and 1 tbsp red chili powder, salt,\n" +
                "1 tsp cumin seed powder and 1 tsp coriander seed powder.\n" +
                "\n2- When the tomatoes are cooked then add in ½ kg mix vegetables and 1 cup boiled " +
                "\nred beans.\n" +
                "\n3- Add in 1 cup water and let the vegetables cook. When the water dries \n" +
                "and the vegetables are completely cooked then add in cream.Sauté some curry \n" +
                "leaves in oil and add it on the mixed vegetables. Dish it out and serve.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("1- Take some oil in the pan and sauté ginger garlic paste and 1 chopped onion " +
                    "\nfor 3-4 minutes. Add in 2 chopped tomatoes and 1 tbsp red chili powder, salt,\n" +
                    "1 tsp cumin seed powder and 1 tsp coriander seed powder.\n" +
                    "\n2- When the tomatoes are cooked then add in ½ kg mix vegetables and 1 cup boiled " +
                    "\nred beans.\n" +
                    "\n3- Add in 1 cup water and let the vegetables cook. When the water dries \n" +
                    "and the vegetables are completely cooked then add in cream.Sauté some curry \n" +
                    "leaves in oil and add it on the mixed vegetables. Dish it out and serve.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Red chili powder 1 tbsp");
            //Ingredients2
            text2.setText("Cumin seed powder 1 tsp");
            //Ingredients3
            text3.setText("Curry leaves 2-3");
            //Ingredients4
            text4.setText("Oil 2 tbsp");
            //Ingredients5
            text5.setText("Salt to taste");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1- Take some oil in the pan and sauté ginger garlic paste and 1 chopped onion " +
                    "\nfor 3-4 minutes. Add in 2 chopped tomatoes and 1 tbsp red chili powder, salt,\n" +
                    "1 tsp cumin seed powder and 1 tsp coriander seed powder.\n" +
                    "\n2- When the tomatoes are cooked then add in ½ kg mix vegetables and 1 cup boiled " +
                    "\nred beans.\n" +
                    "\n3- Add in 1 cup water and let the vegetables cook. When the water dries \n" +
                    "and the vegetables are completely cooked then add in cream.Sauté some curry \n" +
                    "leaves in oil and add it on the mixed vegetables. Dish it out and serve.");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Mix Vegetables ½ kg");
            //Ingredients2
            text2.setText("Tomatoes (chopped) 2");
            //Ingredients3
            text3.setText("Potatoes (cubed) 1 cup");
            //Ingredients4
            text4.setText("Onion (chopped) 1");
            //Ingredients5
            text5.setText("Ginger Garlic Paste 2 tbsp");
            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
