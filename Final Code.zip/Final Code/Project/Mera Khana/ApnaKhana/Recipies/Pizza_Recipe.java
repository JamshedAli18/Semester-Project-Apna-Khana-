package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pizza_Recipe  extends FastFoodTemplate implements ActionListener {

    public Pizza_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\pizza.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Pizza-Cover.jpg"));

        //Heading...............................
        heading.setText("Pizza");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Mon salwa plain paratha");
        //Ingredients2
        text2.setText("Mozzarella cheese grated");
        //Ingredients3
        text3.setText("Lal mirch (Red chilli) crushed");
        //Ingredients4
        text4.setText("Pizza sauce as required");
        //Ingredients5
        text5.setText("Mon slawa Tikka chicken chunks");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) Heat griddle,place paratha and cook from both sides until done & set aside." +
                "\n\n2) Place another paratha and cook from one side,turn the side and turn off the flame." +
                "\n\n3) Add mozzarella cheese,red chilli crushed and place another cooked paratha" +
                "\n\n4) Add & spread pizza sauce,add chicken tikka chunks,jalapenos,onion,\ncheddar cheese," +
                " mozzarella cheese, capsicum,black olives,dried oregano and red chilli crushed." +
                "\n\n5) Cover & turn on the flame and cook on low flame until cheese \nmelts (approx. 2-3 minutes)");


        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Heat griddle,place paratha and cook from both sides until done & set aside." +
                    "\n\n2) Place another paratha and cook from one side,turn the side and turn off the flame." +
                    "\n\n3) Add mozzarella cheese,red chilli crushed and place another cooked paratha" +
                    "\n\n4) Add & spread pizza sauce,add chicken tikka chunks,jalapenos,onion,\ncheddar cheese," +
                    " mozzarella cheese, capsicum,black olives,dried oregano and red chilli crushed." +
                    "\n\n5) Cover & turn on the flame and cook on low flame until cheese \nmelts (approx. 2-3 minutes)");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Pyaz (Onion) sliced");
            //Ingredients7
            text2.setText("Cheddar cheese grated");
            //Ingredients8
            text3.setText("Ingredient eight");
            //Ingredients9
            text4.setText("Lal mirch (Red chilli) crushed");
            //Ingredients10
            text5.setText("Shimla mirch (Capsicum) julienne");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Heat griddle,place paratha and cook from both sides until done & set aside." +
                    "\n\n2) Place another paratha and cook from one side,turn the side and turn off the flame." +
                    "\n\n3) Add mozzarella cheese,red chilli crushed and place another cooked paratha" +
                    "\n\n4) Add & spread pizza sauce,add chicken tikka chunks,jalapenos,onion,\ncheddar cheese," +
                    " mozzarella cheese, capsicum,black olives,dried oregano and red chilli crushed." +
                    "\n\n5) Cover & turn on the flame and cook on low flame until cheese \nmelts (approx. 2-3 minutes)");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Mon salwa plain paratha");
            //Ingredients2
            text2.setText("Mozzarella cheese grated");
            //Ingredients3
            text3.setText("Lal mirch (Red chilli) crushed");
            //Ingredients4
            text4.setText("Pizza sauce as required");
            //Ingredients5
            text5.setText("Mon slawa Tikka chicken chunks");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
    }

