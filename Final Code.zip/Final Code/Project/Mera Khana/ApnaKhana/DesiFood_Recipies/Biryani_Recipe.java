package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Biryani_Recipe extends DesiFood_Template implements ActionListener {

    public Biryani_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Biryani.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Biryani-Cover.jpg"));

        //
        //Heading...............................
        heading.setText("Biryani");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("2 cups Basmati rice");
        //Ingredients2
        text2.setText("Onioin 3 large, sliced");
        //Ingredients3
        text3.setText("1tsp Greeen Chilli paste");
        //Ingredients4
        text4.setText("7tbsp Oil");
        //Ingredients5
        text5.setText("3/4 Kilo Chicken pieces");


        //Steps to prepare Dish..................
        Text_area.setText("\n1. Make a mixture with tomato yoghurt, puree, green chilli paste, ginger garlic paste,\n red chilli powder, roasted" +
                " cumin powder, turmeric powder, garam masala powder,\ncoriander powder and salt.\n" +
                "\n2. Take the chicken and marinade it in the same mixture. Let it rest for 3-4 hours.\n" +
                "\n3. Put oil in a pan, heat it and fry onions till they turn golden brown.\n" +
                "\n4. Now, to this add the marinated chicken and cook the entire mixture for 10 mints.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource()==Next_btn){
                Text_area.setText("\n5. After that in a pressure cooker, take the rice and add 3 1/2 cups of water to it." +
                        "\n Also, take the saffron, mix with the milk and add to the rice.\n" +
                        "\n6. Lastly, add the cardamom powder and the chicken pieces, along with the marinade.\n" +
                        "\n7. Mix all the ingredients gently, cover with the cooker lid and pressure cook for 1 " +
                        "\nwhistle.\n");

                //Ingredients..........................
                text.setText("Ingredients");
                //Ingredients1
                text1.setText("1 cup yogurt");
                //Ingredients2
                text2.setText("1/2 tomato puree");
                //Ingredients3
                text3.setText("3 1/2 water cups");
                //Ingredients4
                text4.setText("salt as required");
                //Ingredients
                text5.setText("");

                button.remove(Next_btn);
                button.add(Previous_btn);

            }else if(e.getSource()==Previous_btn){

                //Steps to prepare Dish..................
                Text_area.setText("\n1. Make a mixture with tomato yoghurt, puree, green chilli paste, ginger garlic paste,\n red chilli powder, roasted" +
                        " cumin powder, turmeric powder, garam masala powder,\ncoriander powder and salt.\n" +
                        "\n2. Take the chicken and marinade it in the same mixture. Let it rest for 3-4 hours.\n" +
                        "\n3. Put oil in a pan, heat it and fry onions till they turn golden brown.\n" +
                        "\n4. Now, to this add the marinated chicken and cook the entire mixture for 10 mints.");

                text.setText("Ingredients");
                //Ingredients1
                text1.setText("2 cups Basmati rice");
                //Ingredients2
                text2.setText("Onioin 3 large, sliced");
                //Ingredients3
                text3.setText("1tsp Greeen Chilli paste");
                //Ingredients4
                text4.setText("7tbsp Oil");
                //Ingredients5
                text5.setText("3/4 Kilo Chicken pieces");

                button.add(Next_btn);
                button.remove(Previous_btn);

            }
            //Previous Frame Button
            if (e.getSource() == PreviousFrame_Button) {

                frame.dispose();
                Desi_Food obj = new Desi_Food();
            }
    }
}
