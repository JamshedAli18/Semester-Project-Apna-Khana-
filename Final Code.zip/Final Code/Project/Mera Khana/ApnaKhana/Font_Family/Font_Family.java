package ApnaKhana.Font_Family;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class Font_Family {
    public Font Magrib;
    public Font Asap;

    public Font_Family() {
        JLabel text = new JLabel("Ahsan");
        try {

            Magrib = Font.createFont(Font.TRUETYPE_FONT, new File("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\ApnaKhana\\Font_Family\\Maghrib.otf")).deriveFont(100f);
            Asap = Font.createFont(Font.TRUETYPE_FONT, new File("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\ApnaKhana\\Font_Family\\Asap-BoldItalic.otf")).deriveFont(37f);
            GraphicsEnvironment Ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            Ge.registerFont(Magrib);
            Ge.registerFont(Asap);
        } catch (IOException | FontFormatException e) {

        }
    }
}