package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NoodleSoup_Recipe extends ChineeseFood_Template implements ActionListener {

    public NoodleSoup_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Noodle soup.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Noodle-Soup-Cover.jpg"));

        //Heading...............................
        heading.setText("Noodle Soup");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 chicken stock cube");
        //Ingredients2
        text2.setText("50g/1¾oz dried egg noodles ");
        //Ingredients3
        text3.setText("2 spring onions, thinly sliced");
        //Ingredients4
        text4.setText("50g/1¾oz frozen peas");
        //Ingredients5
        text5.setText("50g/1¾oz shredded cooked chicken");

        //Steps to prepare Dish..................
        Text_area.setText("1) Pour 700ml/1¼ pint freshly boiled water into a saucepan, add the stock " +
                "\n  cube and stir well to dissolve." +
                "\n\n2) Add the noodles, spring onions, peas and chicken, bring to the boil and cook for" +
                "\n  5 minutes, or until the noodles and peas are cooked and the chicken is hot through." +
                "\n\n3) Ladle into a deep, wide bowl and, if you fancy, top with the chilli, ginger, "+
                "\n  garlic, coriander and soy sauce. ");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("1) Pour 700ml/1¼ pint freshly boiled water into a saucepan, add the stock " +
                    "\n  cube and stir well to dissolve." +
                    "\n\n2) Add the noodles, spring onions, peas and chicken, bring to the boil and cook for" +
                    "\n  5 minutes, or until the noodles and peas are cooked and the chicken is hot through." +
                    "\n\n3) Ladle into a deep, wide bowl and, if you fancy, top with the chilli, ginger, "+
                    "\n  garlic, coriander and soy sauce. ");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("½ red chilli,");
            //Ingredients7
            text2.setText("¼in/1cm piece fresh root ginger,");
            //Ingredients8
            text3.setText("½ garlic clove, thinly sliced");
            //Ingredients9
            text4.setText("few fresh coriander leaves");
            //Ingredients10
            text5.setText("dash soy sauce");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) Pour 700ml/1¼ pint freshly boiled water into a saucepan, add the stock " +
                    "\n  cube and stir well to dissolve." +
                    "\n\n2) Add the noodles, spring onions, peas and chicken, bring to the boil and cook for" +
                    "\n  5 minutes, or until the noodles and peas are cooked and the chicken is hot through." +
                    "\n\n3) Ladle into a deep, wide bowl and, if you fancy, top with the chilli, ginger, "+
                    "\n  garlic, coriander and soy sauce. ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 chicken stock cube");
            //Ingredients2
            text2.setText("50g/1¾oz dried egg noodles ");
            //Ingredients3
            text3.setText("2 spring onions, thinly sliced");
            //Ingredients4
            text4.setText("50g/1¾oz frozen peas");
            //Ingredients5
            text5.setText("50g/1¾oz shredded cooked chicken");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}
