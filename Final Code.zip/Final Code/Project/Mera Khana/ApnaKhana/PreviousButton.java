package ApnaKhana;

import ApnaKhana.Font_Family.Font_Family;
import javax.swing.*;
import java.awt.*;

public class PreviousButton extends Font_Family {

    JButton Previous_frame = new JButton();

    PreviousButton(){

        Previous_frame.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Back-Button.png"));
        Previous_frame.setBounds(40, 35, 70, 70);
        Previous_frame.setOpaque(false);
        Previous_frame.setBackground(new Color((float) 0, (float) 0, (float) 0, (float) 0.3));
        Previous_frame.setContentAreaFilled(false);
        Previous_frame.setBorderPainted(false);
        Previous_frame.setFocusable(false);

    }
}
