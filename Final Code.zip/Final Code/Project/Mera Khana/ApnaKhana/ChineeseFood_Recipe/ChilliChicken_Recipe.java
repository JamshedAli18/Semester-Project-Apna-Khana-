package ApnaKhana.ChineeseFood_Recipe;
import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChilliChicken_Recipe extends ChineeseFood_Template implements ActionListener {

    public ChilliChicken_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Chilli Chicken.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Chilli-Chicken-Cover.jpg"));

        //Heading...............................
        heading.setText("Chilli Chicken");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("2 chicken breasts");
        //Ingredients2
        text2.setText("1 teaspoon salt");
        //Ingredients3
        text3.setText("½ teaspoon pepper");
        //Ingredients4
        text4.setText("1 egg, beaten");
        //Ingredients5
        text5.setText("¾ cup flour(100 g)");

        //Steps to prepare Dish..................
        Text_area.setText("1) In a bowl,add chicken,ginger garlic paste,vinegar,soy sauce,salt,black pepper\n " +
                "  powder,all-purpose flour, cornflour,egg & mix well,cover & marinate for 30 minutes." +
                "\n\n2) In a wok,heat cooking oil,fry marinated chicken on medium flame until golden brown." +
                ".\n\n3) In a bowl,add water,soy sauce,tomato ketchup,hot sauce,black pepper powder,\n salt,red chilli powder," +
                " chicken powder,cornflour,whisk well & set aside." +"\n\n4)  In a wok,add cooking oil,garlic,ginger,green chillies " +
                "& sauté for a minute." +
                "\n\n5) Add onion & mix well for 1 minute.");


        //NextButton.................
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("6) Add prepared sauce,mix well and cook until sauce is thick & mix continuously" +
                    "\n\n7) Now add fried chicken & mix well.\n" +
                    "  Add green onion leaves & mix well. Garnish with green onion leaves & serve!");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1 green pepper, sliced");
            //Ingredients7
            text2.setText("1 red pepper, sliced");
            //Ingredients8
            text3.setText("rice, to serve");
            //Ingredients9
            text4.setText("1 red chilli, chopped");
            //Ingredients10
            text5.setText("3 tablespoons soy sauce  , " +
                    "2 tablespoons tomato puree");
            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) In a bowl,add chicken,ginger garlic paste,vinegar,soy sauce,salt,black pepper\n " +
                    "  powder,all-purpose flour, cornflour,egg & mix well,cover & marinate for 30 minutes." +
                    "\n\n2) In a wok,heat cooking oil,fry marinated chicken on medium flame until golden brown." +
                    ".\n\n3) In a bowl,add water,soy sauce,tomato ketchup,hot sauce,black pepper powder,\n salt,red chilli powder," +
                    " chicken powder,cornflour,whisk well & set aside." +"\n\n4)  In a wok,add cooking oil,garlic,ginger,green chillies " +
                    "& sauté for a minute." +
                    "\n\n5) Add onion & mix well for 1 minute.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("2 chicken breasts");
            //Ingredients2
            text2.setText("1 teaspoon salt");
            //Ingredients3
            text3.setText("½ teaspoon pepper");
            //Ingredients4
            text4.setText("1 egg, beaten");
            //Ingredients5
            text5.setText("¾ cup flour(100 g)");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}
