package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Burger_Recipe extends FastFoodTemplate implements ActionListener {

    public Burger_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\burger.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Burger-Cover.jpg"));

        //Heading...............................
        heading.setText("Burger");

        //Ingredients..........................
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 onion, peeled and finely chopped");
        //Ingredients2
        text2.setText("1 x 500g pack British Beef Steak Mince 15% fat");
        //Ingredients3
        text3.setText("1 tsp mixed dried herbs");
        //Ingredients4
        text4.setText("1 egg, beaten");
        //Ingredients5
        text5.setText("4 slices mature Cheddar (optional)");


        //Steps to prepare Dish..................
        Text_area.setText("1) Heat the olive oil in a frying pan, add the onion and cook for 5 minutes until" +
                "\n    softened and starting" +
                " to turn golden. Set aside.\n\n2) In a bowl, combine the beef mince with" +
                "the herbs and the egg.\n    Season, add the onions and mix well." +
                "Using your\n     hands, shape into 4 patties.\n\n3) Cook the burgers on a preheated barbecue or" +
                "griddle for 5-6 minutes\n    on each side. While the second side is cooking, " +
                "\n     lay a slice of cheese on top to melt slightly (if using).");


        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("4 Meanwhile, lightly toast the cut-sides of the buns on the barbecue.Fill with the" +
                    "\n   lettuce, burgers and tomato slices. Serve with ketchup, if you like.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("few round lettuce leaves, torn");
            //Ingredients7
            text2.setText("1 beef tomato, sliced");
            //Ingredients8
            text3.setText("ketchup, to serve (optional)");
            //Ingredients9
            text4.setText("½ tbsp olive oil");
            //Ingredients10
            text5.setText("4 white rolls");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) Heat the olive oil in a frying pan, add the onion and cook for 5 minutes until" +
                    "\n    softened and starting" +
                    " to turn golden. Set aside.\n\n2) In a bowl, combine the beef mince with" +
                    "the herbs and the egg.\n    Season, add the onions and mix well." +
                    "Using your\n     hands, shape into 4 patties.\n\n3) Cook the burgers on a preheated barbecue or" +
                    "griddle for 5-6 minutes\n    on each side. While the second side is cooking, " +
                    "\n     lay a slice of cheese on top to melt slightly (if using).");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 onion, peeled and finely chopped");
            //Ingredients2
            text2.setText("1 x 500g pack British Beef Steak Mince 15% fat");
            //Ingredients3
            text3.setText("1 tsp mixed dried herbs");
            //Ingredients4
            text4.setText("1 egg, beaten");
            //Ingredients5
            text5.setText("4 slices mature Cheddar (optional)");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Fast_Food obj = new Fast_Food();
        }
    }
}
