package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Popeyes_Recipe extends FastFoodTemplate implements ActionListener {

    public Popeyes_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Popeyes.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Popeyes-Cover.jpg"));

        //Heading...............................
        heading.setText("Popeyes");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("3 cups whole buttermilk");
        //Ingredients2
        text2.setText("3 tablespoons hot sauce (such as Tabasco), divided");
        //Ingredients3
        text3.setText("1 (2 1/2- to 3-lb.) whole chicken, cut into 8 pieces");
        //Ingredients4
        text4.setText("3 large eggs");
        //Ingredients5
        text5.setText("⅓ cup water , Peanut oil");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) Stir together buttermilk and 2 tablespoons of the hot sauce in large bowl. Submerge" +
                "\nchicken in buttermilk mixture; cover and refrigerate overnight." +
                "\n\n2) Whisk together eggs, water, and remaining 1 tablespoon hot sauce in a \nmedium bowl. Stir together " +
                "flour, salt, cayenne pepper, black pepper, \npaprika, and garlic powder in a large bowl."  +
                "\n\n3) Pour oil to a depth of 2 1/2 inches in a large Dutch oven, and heat to 325°F over" +
                "\nmedium-high. Remove chicken from buttermilk mixture; discard buttermilk mixture." +
                "\n Dip chicken pieces in egg mixture, and dredge in flour mixture; shaking off excess" +
                "\nflour. Dip in egg mixture, and dredge in flour again; shaking off excess flour. ");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\n\n\n4) Carefully add chicken to hot oil, 4 pieces at a time; fry until golden brown and " +
                    "\ncooked through, 8 to 10 minutes, maintaining oil temperature of 325°F." +
                    "\nDrain on paper towels. Repeat with remaining chicken pieces.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("2 teaspoons paprika");
            //Ingredients7
            text2.setText("2 teaspoons black pepper");
            //Ingredients8
            text3.setText("3 teaspoons cayenne pepper");
            //Ingredients9
            text4.setText("2 ½ tablespoons kosher salt");
            //Ingredients10
            text5.setText("1 ½ teaspoons garlic powder");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Stir together buttermilk and 2 tablespoons of the hot sauce in large bowl. Submerge" +
                    "\nchicken in buttermilk mixture; cover and refrigerate overnight." +
                    "\n\n2) Whisk together eggs, water, and remaining 1 tablespoon hot sauce in a \nmedium bowl. Stir together " +
                    "flour, salt, cayenne pepper, black pepper, \npaprika, and garlic powder in a large bowl."  +
                    "\n\n3) Pour oil to a depth of 2 1/2 inches in a large Dutch oven, and heat to 325°F over" +
                    "\nmedium-high. Remove chicken from buttermilk mixture; discard buttermilk mixture." +
                    "\n Dip chicken pieces in egg mixture, and dredge in flour mixture; shaking off excess" +
                    "\nflour. Dip in egg mixture, and dredge in flour again; shaking off excess flour. ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("3 cups whole buttermilk");
            //Ingredients2
            text2.setText("3 tablespoons hot sauce (such as Tabasco), divided");
            //Ingredients3
            text3.setText("1 (2 1/2- to 3-lb.) whole chicken, cut into 8 pieces");
            //Ingredients4
            text4.setText("3 large eggs");
            //Ingredients5
            text5.setText("⅓ cup water , Peanut oil");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }

}
