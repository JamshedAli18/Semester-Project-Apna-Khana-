package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Shashlik_Recipe extends ChineeseFood_Template implements ActionListener {

    public Shashlik_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Shashlik.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Shashlik-Cover.jpg"));

        //Heading...............................
        heading.setText("Shashlik");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("500 gm chicken boneless");
        //Ingredients2
        text2.setText("2 medium tomato");
        //Ingredients3
        text3.setText("2 tablespoon yoghurt (curd)");
        //Ingredients4
        text4.setText("2 inch ginger");
        //Ingredients5
        text5.setText("1 teaspoon coriander powder");

        //Steps to prepare Dish..................
        Text_area.setText("1) Cut chicken and vegetables in cubes." +
                "\n\n2) In a bowl add chicken with garlic/ ginger and all your spices." +
                "\n\n3) Marinate it for 1 hour." +
                " \n\n4) Cut the bell pepper, tomato and onion in square shape." +
                "\n\n5) Assemble the chicken and vegies in a shashlik stick" +
                "\n\n6) In a frying pan heat 2-3 tablespoon of oil and place your sticks." +
                "\n Keep turning the sides so all the sides are cooked evenly." );

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("6) Shashlik sticks can be baked. Preheat oven at 180 degrees and bake shashlik" +
                    "\n stick for 15-20 minutes.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("2 teaspoon powdered red chilli");
            //Ingredients7
            text2.setText("1 medium onion");
            //Ingredients8
            text3.setText("1 medium capsicum (green pepper)");
            //Ingredients9
            text4.setText("6 cloves garlic");
            //Ingredients10
            text5.setText("1 teaspoon black pepper");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) Cut chicken and vegetables in cubes." +
                    "\n\n2) In a bowl add chicken with garlic/ ginger and all your spices." +
                    "\n\n3) Marinate it for 1 hour." +
                    " \n\n4) Cut the bell pepper, tomato and onion in square shape." +
                    "\n\n5) Assemble the chicken and vegies in a shashlik stick" +
                    "\n\n6) In a frying pan heat 2-3 tablespoon of oil and place your sticks." +
                    "\n Keep turning the sides so all the sides are cooked evenly." );

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("500 gm chicken boneless");
            //Ingredients2
            text2.setText("2 medium tomato");
            //Ingredients3
            text3.setText("2 tablespoon yoghurt (curd)");
            //Ingredients4
            text4.setText("2 inch ginger");
            //Ingredients5
            text5.setText("1 teaspoon coriander powder");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();

        }
    }
}
