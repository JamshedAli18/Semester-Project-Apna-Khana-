package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FriedRice_Recipe extends ChilliChicken_Recipe implements ActionListener {

    public FriedRice_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Fried rice.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Fried-Rice-Cover.jpg"));

        //Heading...............................
        heading.setText("Fried Rice");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("White long grain rice");
        //Ingredients2
        text2.setText("Small white onion  ");
        //Ingredients3
        text3.setText("Peas and Carrots.");
        //Ingredients4
        text4.setText("Eggs");
        //Ingredients5
        text5.setText("Sesame Oil ");

        //Steps to prepare Dish..................
        Text_area.setText("1) In a skillet, over medium heat add 1 teaspoon of oil." +
                "\n\n2) Add your protein and sauté for 1 minute or until lightly browned. " +
                "\n\n3) Add chopped carrots & cook for another minute. " +
                " \n\n4) Add the white parts of the green onions.  " +
                " \n\n5) Stir and transfer to a serving dish. ");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){
            Text_area.setText("Scramling the Egg...... "+
                    "\n\n 6) In the same pan, add another 1 teaspoon of oil.\n" +
                    " Pour in the eggs and cook until scrambled. "+ "\n\n7) Add the eggs to the other ingredients " +
                    "in the serving dish.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Soy Sauce");
            //Ingredients7
            text2.setText("Green Onions-");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){
            Text_area.setText("1) In a skillet, over medium heat add 1 teaspoon of oil." +
                    "\n\n2) Add your protein and sauté for 1 minute or until lightly browned. " +
                    "\n\n3) Add chopped carrots & cook for another minute. " +
                    " \n\n4) Add the white parts of the green onions.  " +
                    " \n\n5) Stir and transfer to a serving dish. ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("White long grain rice");
            //Ingredients2
            text2.setText("Small white onion  ");
            //Ingredients3
            text3.setText("Peas and Carrots.");
            //Ingredients4
            text4.setText("Eggs");
            //Ingredients5
            text5.setText("Sesame Oil ");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}
