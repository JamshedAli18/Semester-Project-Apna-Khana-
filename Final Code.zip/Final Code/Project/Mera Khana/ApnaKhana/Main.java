package ApnaKhana;

import ApnaKhana.Font_Family.Font_Family;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Categories extends Font_Family implements ActionListener{

    JFrame jframe= new JFrame();
    JPanel Background_Overly = new JPanel();
    JLabel Background = new JLabel();
    JLabel Logo = new JLabel();
    JLabel Fast_Food = new JLabel();
    JLabel Sweet_Dishes = new JLabel();
    JLabel Chinease_Food = new JLabel();
    JLabel Cinass = new JLabel();
    JLabel bottom = new JLabel();
    JButton Fast_Food_Next_btn = new JButton("Fast Food");
    JButton Sweet_Dishes_Next_btn = new JButton("Sweet Dishes");
    JButton Chinease_Dishes_Next_btn = new JButton("Chinease Food");
    JButton Desi_Food_Next_btn = new JButton( "Desi Food");
    JLabel Heading_Text = new JLabel();

    //Constructor Section
   public Categories() {

        //Favicon Section
        ImageIcon favicon = new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Favicon.png");
        jframe.setIconImage(favicon.getImage());

        //Background Section
        Background.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\background-(2).png"));
        Background.setBounds(0 , 0 , 1270 , 720);

        //Logo Section
        Logo.setIcon(new ImageIcon("\\D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\PicturesLogo.png"));
        Logo.setBounds(40 , -5 , 300 , 180);

        //Categories Text Setting
        Heading_Text.setText("Categories");
        Heading_Text.setFont(Magrib);
        Heading_Text.setForeground(Color.WHITE);
        Heading_Text.setBounds(470, 20, 400, 100);

        //Fast Food Setting
        Fast_Food.setText("Fast Food");
        Fast_Food.setFont(Asap);
        Fast_Food.setForeground(Color.white);
        Fast_Food.setAlignmentX(Component.CENTER_ALIGNMENT);
        Fast_Food_Next_btn.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Main Page Pictures\\Fast Food.png"));
        Fast_Food_Next_btn.setBounds(10 ,180,300 , 400);
        Fast_Food_Next_btn.setOpaque(false);
        Fast_Food_Next_btn.setContentAreaFilled(false);
        Fast_Food_Next_btn.setFocusable(false);
        Fast_Food_Next_btn.setBorderPainted(false);
        Fast_Food_Next_btn.addActionListener(this);

        //Sweet Dishes Setting
        Sweet_Dishes.setText("Sweet Dishes");
        Sweet_Dishes.setFont(Asap);
        Sweet_Dishes.setForeground(Color.white);
        Sweet_Dishes.setAlignmentX(Component.CENTER_ALIGNMENT);
        Sweet_Dishes_Next_btn.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Main Page Pictures\\Sweet Dishes.png"));
        Sweet_Dishes_Next_btn.setOpaque(false);
        Sweet_Dishes_Next_btn.setContentAreaFilled(false);
        Sweet_Dishes_Next_btn.setFocusable(false);
        Sweet_Dishes_Next_btn.setBorderPainted(false);
        Sweet_Dishes_Next_btn.addActionListener(this);
        Sweet_Dishes_Next_btn.setBounds(320 ,180,300 , 400 );


        //Chinease Dishes Setting
        Chinease_Food.setText("Chinease");
        Chinease_Food.setFont(Asap);
        Chinease_Food.setForeground(Color.WHITE);
        Chinease_Food.setAlignmentX(Component.CENTER_ALIGNMENT);
        Chinease_Dishes_Next_btn.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Main Page Pictures\\Chinease Food.png"));
        Chinease_Dishes_Next_btn.setBounds( 630,180,300 , 400);
        Chinease_Dishes_Next_btn.setOpaque(false);
        Chinease_Dishes_Next_btn.setContentAreaFilled(false);
        Chinease_Dishes_Next_btn.setFocusable(false);
        Chinease_Dishes_Next_btn.setBorderPainted(false);
        Chinease_Dishes_Next_btn.addActionListener(this);

        //Desi Food Setting
        Cinass.setText("Desi Food");
        Cinass.setFont(Asap);
        Cinass.setForeground(Color.WHITE);
        Cinass.setAlignmentX(Component.CENTER_ALIGNMENT);
        Desi_Food_Next_btn.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Main Page Pictures\\Desi Food.png"));
        Desi_Food_Next_btn.setBounds( 940,180,300 , 400);
        Desi_Food_Next_btn.setOpaque(false);
        Desi_Food_Next_btn.setContentAreaFilled(false);
        Desi_Food_Next_btn.setFocusable(false);
        Desi_Food_Next_btn.setBorderPainted(false);
        Desi_Food_Next_btn.addActionListener(this);

        //Coded By Code Worriors Setting
        bottom.setText("About Team");
        bottom.setFont(new Font("Courier" , Font.ITALIC , 18));
        bottom.setForeground(Color.white);
        bottom.setBounds(10 , 610 , 500 , 100);

        //Jframe Adding Section
        Fast_Food_Next_btn.add(Fast_Food);
        Sweet_Dishes_Next_btn.add(Sweet_Dishes);
        Chinease_Dishes_Next_btn.add(Chinease_Food);
        Desi_Food_Next_btn.add(Cinass);
        jframe.add(bottom);
        jframe.add(Fast_Food_Next_btn);
        jframe.add(Desi_Food_Next_btn);
        jframe.add(Chinease_Dishes_Next_btn);
        jframe.add(Sweet_Dishes_Next_btn);
        jframe.add(Heading_Text);
        jframe.add(Logo);
        jframe.add(Background);
        jframe.setSize(1270 , 720);
        jframe.setResizable(false);
        jframe.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //Buttons Events
        if(e.getSource()==Fast_Food_Next_btn){

            jframe.dispose();
            Fast_Food fastFood = new Fast_Food();

        }else if(e.getSource()==Sweet_Dishes_Next_btn){

            jframe.dispose();
            Sweet_Dishes Sweet_Dishes = new Sweet_Dishes();

        }else if(e.getSource()==Chinease_Dishes_Next_btn){

            jframe.dispose();
            Chinees_Dishes Chinees_Dishes = new Chinees_Dishes();

        }else if(e.getSource()==Desi_Food_Next_btn){

            jframe.dispose();
            Desi_Food Desi_Food = new Desi_Food();
        }
    }
}
public class Main {
    public static void main(String[] args) {
        SplashScreenDemo obj = new SplashScreenDemo();
        Categories Main_Page = new Categories();

    }
}
