package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Samosa_Recipe extends DesiFood_Template implements ActionListener {

    public Samosa_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Samosy.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Sammosy-Cover.jpg"));

        //Heading...............................
        heading.setText("Samosa");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 cup all purpose flour (Maida)");
        //Ingredients2
        text2.setText("Water to Knead dough");
        //Ingredients3
        text3.setText("2tbsp oil");
        //Ingredients4
        text4.setText("Little salt");
        //Ingredients5
        text5.setText("3-4 Potatoes (boiled, peeled & mashed)");

        //Steps to prepare Dish..................#
        Text_area.setText("\n1. Mix all the ingredients (salt, oil, ajwain) except water.\n" +
                "\n2. Add a little water at a time.\n" +
                "\n3. Pat and knead well for several times into a soft pliable dough.\n" +
                "\n4. In a bowl add mashed potatoes and all dry masalas (salt, chili powder," +
                "\n mango powder, garam masala)and green chilles, ginger and Mix well.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("5. Add green peas, cashews and raisins and mix well.\n" +
                    "\n6. Make small rolls of dough and roll it into a 4-5 diameter circle.\n" +
                    "\n7. Place a spoon of filling in the cone and seal the third side using " +
                    "\na drop of water.\n" +
                    "\n8. Heat oil in a kadhai and deep fry till golden brown.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1/2 cup Green Peas (boiled)");
            //Ingredients2
            text2.setText("1-2 Green Chilies (finely chopped)");
            //Ingredients3
            text3.setText("1/2tsp Ginger (crushed)");
            //Ingredients4
            text4.setText("1tbsp coriander finely chopped");
            //Ingredients5
            text5.setText("1/2tsp Garam masala");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1. Mix all the ingredients (salt, oil, ajwain) except water.\n" +
                    "\n2. Add a little water at a time.\n" +
                    "\n3. Pat and knead well for several times into a soft pliable dough.\n" +
                    "\n4. In a bowl add mashed potatoes and all dry masalas (salt, chili powder," +
                    "\n mango powder, garam masala)and green chilles, ginger and Mix well.");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 cup all purpose flour (Maida)");
            //Ingredients2
            text2.setText("Water to Knead dough");
            //Ingredients3
            text3.setText("2tbsp oil");
            //Ingredients4
            text4.setText("Little salt");
            //Ingredients5
            text5.setText("3-4 Potatoes (boiled, peeled & mashed)");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
