package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SpringRoll_Recipe extends ChineeseFood_Template implements ActionListener {

    public SpringRoll_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Spring rolls.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Spring-Rolls-Cover.jpg"));

        //Heading...............................
        heading.setText("Spring Roll");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 package spring roll wrappers");
        //Ingredients2
        text2.setText("3 carrots shredded");
        //Ingredients3
        text3.setText("3 small cucumbers sliced thin");
        //Ingredients4
        text4.setText("1/4 cup fresh basil");
        //Ingredients5
        text5.setText("2 limes");

        //Steps to prepare Dish..................
        Text_area.setText("1) To prepare, chop all vegetables into slices and have ready next to a clean," +
                " \n  dry cutting board. I used a bit of sesame oil on a paper towel to wipe down" +
                "\n  the board and ensure the wraps don’t stick." +
                "\n\n2) Fill a shallow bowl with water and dip one spring roll rice paper into the water," +
                "\n  submerging for around 10 seconds. Shake lightly before placing on the clean " +
                "\n  cutting board. Spread a drizzle of sesame oil on the rice paper." +
                "\n\n3) Add your vegetables! You can use what you love but today, I just used what I had in" +
                "\n my fridge: basil, carrots, cucumber, and a little avocado." +
                " \n\n4)  I finished by drizzling on the juice of a lime— about 1/4 of a lime per spring roll " );

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("5) onion and sprinkling on some everything but the bagel seasoning; you" +
                    "\n   can make this at home by using sesame seeds,onion powder and garlic\n  powder.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("sesame seeds onion and garlic powder");
            //Ingredients7
            text2.setText("Sesame oil");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) To prepare, chop all vegetables into slices and have ready next to a clean," +
                    " \n  dry cutting board. I used a bit of sesame oil on a paper towel to wipe down" +
                    "\n  the board and ensure the wraps don’t stick." +
                    "\n\n2) Fill a shallow bowl with water and dip one spring roll rice paper into the water," +
                    "\n  submerging for around 10 seconds. Shake lightly before placing on the clean " +
                    "\n  cutting board. Spread a drizzle of sesame oil on the rice paper." +
                    "\n\n3) Add your vegetables! You can use what you love but today, I just used what I had in" +
                    "\n my fridge: basil, carrots, cucumber, and a little avocado." +
                    " \n\n4)  I finished by drizzling on the juice of a lime— about 1/4 of a lime per spring roll " );

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 package spring roll wrappers");
            //Ingredients2
            text2.setText("3 carrots shredded");
            //Ingredients3
            text3.setText("3 small cucumbers sliced thin");
            //Ingredients4
            text4.setText("1/4 cup fresh basil");
            //Ingredients5
            text5.setText("2 limes");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();

        }
    }
}
