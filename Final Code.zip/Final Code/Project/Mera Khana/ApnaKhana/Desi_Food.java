package ApnaKhana;

import ApnaKhana.DesiFood_Recipies.*;
import ApnaKhana.SweetDishes_Recipies.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.NavigableSet;

public class Desi_Food extends PreviousButton implements ActionListener {

    JFrame frame = new JFrame();
    JLabel Background = new JLabel();
    JLabel Heading_Text = new JLabel();
    JButton biryani = new JButton();
    JButton friedfish = new JButton();
    JButton golGappy = new JButton();
    JButton pakora = new JButton();
    JButton samosa= new JButton();
    JButton chicken_karhai = new JButton();
    JButton mutton_karahi = new JButton();
    JButton paai = new JButton();
    JButton chapli_kabab = new JButton();
    JButton sarsonKaSaag = new JButton();
    JButton masoorKidaal = new JButton();
    JButton mix_sabzi = new JButton();
    JLabel biryani_Image = new JLabel();
    JLabel friedfish_Image = new JLabel();
    JLabel golGappy_Image = new JLabel();
    JLabel pakora_Image = new JLabel();
    JLabel samosa_Image = new JLabel();
    JLabel chicken_karhai_Image = new JLabel();
    JLabel mutton_karahi_Image = new JLabel();
    JLabel paai_Image = new JLabel();
    JLabel chapli_kabab_Image = new JLabel();
    JLabel sarsonKaSaag_Image = new JLabel();
    JLabel masoorKidaal_Image = new JLabel();
    JLabel  mix_sabzi_Image = new JLabel();

    public Desi_Food(){

        //Favicon
        ImageIcon favicon = new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Favicon.png");
        frame.setIconImage(favicon.getImage());

        //Background
        Background.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Background.jpg"));
        Background.setBounds(0, 0, 1270, 720);

        //Menu Heading
        Heading_Text.setText("Menu");
        Heading_Text.setFont(Magrib);
        Heading_Text.setForeground(Color.black);
        Heading_Text.setBounds(520, 20, 400, 100);

        //Biryani Text Section
        biryani.setText("Biryani");
        biryani.setFont(Asap);
        biryani.setForeground(Color.BLACK);
        biryani.setBounds(-35, 140, 290, 150);
        biryani.setOpaque(false);
        biryani.setContentAreaFilled(false);
        biryani.setBorderPainted(false);
        biryani.setFocusable(false);

        //1. biryani Image Section
        biryani_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\biryani.png"));
        biryani_Image.setBounds(280, 150, 120, 130);
        biryani_Image.setOpaque(false);

        //Fried fish Text Section
        friedfish.setText("Fried Fish");
        friedfish.setFont(Asap);
        friedfish.setForeground(Color.BLACK);
        friedfish.setBounds(5, 270, 250, 150);
        friedfish.setOpaque(false);
        friedfish.setContentAreaFilled(false);
        friedfish.setBorderPainted(false);
        friedfish.setFocusable(false);

        //Fried fish Image Section
        friedfish_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Fried Fish.png"));
        friedfish_Image.setBounds(280, 280, 120, 130);
        friedfish_Image.setOpaque(false);

        //Gol gappy Text Section
        golGappy.setText("Gol Gappy");
        golGappy.setFont(Asap);
        golGappy.setForeground(Color.BLACK);
        golGappy.setBounds(25, 400, 230, 150);
        golGappy.setOpaque(false);
        golGappy.setContentAreaFilled(false);
        golGappy.setBorderPainted(false);
        golGappy.setFocusable(false);

        //GolGappy Image Section
        golGappy_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Gol Gappy.png"));
        golGappy_Image.setBounds(280, 410, 120, 130);
        golGappy_Image.setOpaque(false);

        //Pakory Text Section
        pakora.setText("Pakory");
        pakora.setFont(Asap);
        pakora.setForeground(Color.BLACK);
        pakora.setBounds(-35, 530, 290, 150);
        pakora.setOpaque(false);
        pakora.setContentAreaFilled(false);
        pakora.setBorderPainted(false);
        pakora.setFocusable(false);

        //Pakora Image Section
        pakora_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Pakory.png"));
        pakora_Image.setBounds(280, 540, 120, 130);
        pakora_Image.setOpaque(false);

        //Samosa Text Section
        samosa.setText("Samosy");
        samosa.setFont(Asap);
        samosa.setForeground(Color.BLACK);
        samosa.setBounds(350, 150, 290, 150);
        samosa.setOpaque(false);
        samosa.setContentAreaFilled(false);
        samosa.setBorderPainted(false);
        samosa.setFocusable(false);

        //Samoasa Image Section
        samosa_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Samosa.png"));
        samosa_Image.setBounds(700, 150, 120, 130);
        samosa_Image.setOpaque(false);

        //Chicken karhai Text Section
        chicken_karhai.setText("Chicken karhai ");
        chicken_karhai.setFont(Asap);
        chicken_karhai.setForeground(Color.BLACK);
        chicken_karhai.setBounds(400, 270, 290, 150);
        chicken_karhai.setOpaque(false);
        chicken_karhai.setContentAreaFilled(false);
        chicken_karhai.setBorderPainted(false);
        chicken_karhai.setFocusable(false);

        //Chicken karhai Image Section
        chicken_karhai_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Chicken Karhai.png"));
        chicken_karhai_Image.setBounds(700, 280, 120, 130);
        chicken_karhai_Image.setOpaque(false);

        //Mutton karhai Text Section
        mutton_karahi.setText("Mutton Karhai");
        mutton_karahi.setFont(Asap);
        mutton_karahi.setForeground(Color.BLACK);
        mutton_karahi.setBounds(395, 400, 300, 150);
        mutton_karahi.setOpaque(false);
        mutton_karahi.setContentAreaFilled(false);
        mutton_karahi.setBorderPainted(false);
        mutton_karahi.setFocusable(false);

        //Mutton karhai Image Section
        mutton_karahi_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Mutton Karhai.png"));
        mutton_karahi_Image.setBounds(700, 410, 120, 130);
        mutton_karahi_Image.setOpaque(false);

        //Pai Text Section
        paai.setText("Paai");
        paai.setFont(Asap);
        paai.setForeground(Color.BLACK);
        paai.setBounds(330, 530, 290, 150);
        paai.setOpaque(false);
        paai.setContentAreaFilled(false);
        paai.setBorderPainted(false);
        paai.setFocusable(false);

        //Paai Image Section
        paai_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Paai.png"));
        paai_Image.setBounds(700, 540, 120, 130);
        paai_Image.setOpaque(false);

        //Chapli kabab Text Section
        chapli_kabab.setText("Chapli Kabaab");
        chapli_kabab.setFont(Asap);
        chapli_kabab.setForeground(Color.BLACK);
        chapli_kabab.setBounds(810, 140, 290, 150);
        chapli_kabab.setOpaque(false);
        chapli_kabab.setContentAreaFilled(false);
        chapli_kabab.setBorderPainted(false);
        chapli_kabab.setFocusable(false);

        //Chapli kabaab Image Section
        chapli_kabab_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Chapli Kabab.png"));
        chapli_kabab_Image.setBounds(1100, 150, 120, 130);
        chapli_kabab_Image.setOpaque(false);

        //Sarson ka saag Text Section
        sarsonKaSaag.setText("Saag");
        sarsonKaSaag.setFont(Asap);
        sarsonKaSaag.setForeground(Color.BLACK);
        sarsonKaSaag.setBounds(740, 270, 290, 150);
        sarsonKaSaag.setOpaque(false);
        sarsonKaSaag.setContentAreaFilled(false);
        sarsonKaSaag.setBorderPainted(false);
        sarsonKaSaag.setFocusable(false);

        //Sarson ka saag Image Section
        sarsonKaSaag_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Saag.png"));
        sarsonKaSaag_Image.setBounds(1100, 280, 120, 130);
        sarsonKaSaag_Image.setOpaque(false);

        //Masoor kee daal Text Section
        masoorKidaal.setText("Masoor daal");
        masoorKidaal.setFont(Asap);
        masoorKidaal.setForeground(Color.BLACK);
        masoorKidaal.setBounds(820, 400, 250, 150);
        masoorKidaal.setOpaque(false);
        masoorKidaal.setContentAreaFilled(false);
        masoorKidaal.setBorderPainted(false);
        masoorKidaal.setFocusable(false);

        //Masoor kee daal Image Section
        masoorKidaal_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Masoor.png"));
        masoorKidaal_Image.setBounds(1100, 410, 120, 130);
        masoorKidaal_Image.setOpaque(false);

        //Mix sabzi Text Section
        mix_sabzi.setText("Mix Sabzi");
        mix_sabzi.setFont(Asap);
        mix_sabzi.setForeground(Color.BLACK);
        mix_sabzi.setBounds(780, 530, 290, 150);
        mix_sabzi.setOpaque(false);
        mix_sabzi.setContentAreaFilled(false);
        mix_sabzi.setBorderPainted(false);
        mix_sabzi.setFocusable(false);

        //Mix sabzi Image Section
        mix_sabzi_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Desi Food\\Mix Sabzi.png"));
        mix_sabzi_Image.setBounds(1100, 540, 120, 130);
        mix_sabzi_Image.setOpaque(false);

        //Adding Buttons Functionalties......................
        biryani.addActionListener(this);
        friedfish.addActionListener(this);
        golGappy.addActionListener(this);
        pakora.addActionListener(this);
        samosa.addActionListener(this);
        chicken_karhai.addActionListener(this);
        mutton_karahi.addActionListener(this);
        paai.addActionListener(this);
        chapli_kabab.addActionListener(this);
        sarsonKaSaag.addActionListener(this);
        masoorKidaal.addActionListener(this);
        mix_sabzi.addActionListener(this);

        //Back button
        Previous_frame.addActionListener(this);

        // Adding in Frame Section
        frame.setVisible(true);
        frame.setLayout(null);
        frame.add(Heading_Text);
        frame.add(biryani);
        frame.add(biryani_Image);
        frame.add(friedfish);
        frame.add(friedfish_Image);
        frame.add(golGappy);
        frame.add(golGappy_Image);
        frame.add(pakora);
        frame.add(pakora_Image);
        frame.add(samosa);
        frame.add(samosa_Image);
        frame.add(chicken_karhai);
        frame.add(chicken_karhai_Image);
        frame.add(mutton_karahi);
        frame.add(mutton_karahi_Image);
        frame.add(paai);
        frame.add(paai_Image);
        frame.add(chapli_kabab);
        frame.add(chapli_kabab_Image);
        frame.add(sarsonKaSaag);
        frame.add(sarsonKaSaag_Image);
        frame.add(masoorKidaal);
        frame.add(masoorKidaal_Image);
        frame.add(mix_sabzi);
        frame.add(mix_sabzi_Image);
        frame.add(Previous_frame);
        frame.add(Background);
        frame.setSize(1270, 720);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //giving instructions.....................
        if(e.getSource()==biryani){

            frame.dispose();
            Biryani_Recipe obj = new Biryani_Recipe();

        }else if(e.getSource()==friedfish){

            frame.dispose();
            FriedFish_Recipe obj = new FriedFish_Recipe();

        }else if(e.getSource()==golGappy){

            frame.dispose();
            GolGappay_Recipe obj = new GolGappay_Recipe();

        }else if(e.getSource()==pakora){

            frame.dispose();
            Pakoray_Recipe obj = new Pakoray_Recipe();

        }else if(e.getSource()==samosa){

            frame.dispose();
            Samosa_Recipe obj = new Samosa_Recipe();

        }else if(e.getSource()==chicken_karhai){

            frame.dispose();
            ChickenKarhai_Recipe obj = new ChickenKarhai_Recipe();

        }else if(e.getSource()==mutton_karahi){

            frame.dispose();
            MuttonKarhai_Recipe obj = new MuttonKarhai_Recipe();

        }else if(e.getSource()==paai){

            frame.dispose();
            Paai_Recipe obj = new Paai_Recipe();

        }else if(e.getSource()==chapli_kabab){

            frame.dispose();
            ChapliKabab_Recipe obj = new ChapliKabab_Recipe();

        }else if(e.getSource()==sarsonKaSaag){

            frame.dispose();
            Saag_Recipe obj = new Saag_Recipe();

        }else if(e.getSource()==masoorKidaal){

            frame.dispose();
            Masoor_Recipe obj = new Masoor_Recipe();

        }else if(e.getSource()==mix_sabzi){

            frame.dispose();
            MixSabzi_Recipe obj = new MixSabzi_Recipe();

        }else if(e.getSource()==Previous_frame){

            frame.dispose();
            Categories Main_Page = new Categories();
        }
    }
}
