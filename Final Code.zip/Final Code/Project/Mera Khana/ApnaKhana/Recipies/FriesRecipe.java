package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FriesRecipe extends FastFoodTemplate implements ActionListener {

   public FriesRecipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\fries.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Fries-Cover.jpg"));

        //Heading...............................
        heading.setText("French Fries");

       //Ingredients sections
       text.setText("Ingredients");
       //Ingredients1
       text1.setText("2 large russet potatoes, washed");
       //Ingredients2
       text2.setText("2 tablespoons olive oil");
       //Ingredients3
       text3.setText("Salt and pepper, to taste");
       //Ingredients4
       text4.setText("");
       //Ingredients5
       text5.setText("");


        //Steps to prepare Dish..................
        Text_area.setText("\n1) Using a mandoline, slice the potatoes into fries. If you don’t have a " +
                "\nmandolin slice the potato into ¼ inch sections." +
                "\n\n2) Next, place the fries in a large bowl and cover with water" +
                "\n\n3) Let the cut potatoes sit in the water for 30 minutes. Drain the water and repeat the" +
                "\nsoaking process with new water for an additional 30 minutes" +
                "\n\n4) After the full hour of soaking, drain the water, and pat fries dry with a paper towel." +
                "\n\n5) Toss with a couple tablespoons of olive oil, salt and pepper.");


        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

       //Previous Frame Button.........................
       PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\n\n6) Preheat Air Fryer to 375°F if required based on the air fryer model that you have." +
                    "\n\n7) Add fries to bottom of air fryer basket, making sure they are in a single " +
                    "\n layer, with a little room between each one." +
                    "\n\n8) Cook for 7 minutes, then shake the basket or flip the fries. Continue " +
                    "\n to cook for an additional 5-7 minutes until crispy and golden brown." +
                    "\n\n9) Serve immediately.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("2 large russet potatoes, washed");
            //Ingredients2
            text2.setText("2 tablespoons olive oil");
            //Ingredients3
            text3.setText("Salt and pepper, to taste");
            //Ingredients4
            text4.setText("");
            //Ingredients5
            text5.setText("");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);
        }
        if(e.getSource()==Previous_btn){
            //Steps to prepare Dish..................
            Text_area.setText("\n1) Using a mandoline, slice the potatoes into fries. If you don’t have a " +
                    "\nmandolin slice the potato into ¼ inch sections." +
                    "\n\n2) Next, place the fries in a large bowl and cover with water" +
                    "\n\n3) Let the cut potatoes sit in the water for 30 minutes. Drain the water and repeat the" +
                    "\nsoaking process with new water for an additional 30 minutes" +
                    "\n\n4) After the full hour of soaking, drain the water, and pat fries dry with a paper towel." +
                    "\n\n5) Toss with a couple tablespoons of olive oil, salt and pepper.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("2 large russet potatoes, washed");
            //Ingredients2
            text2.setText("2 tablespoons olive oil");
            //Ingredients3
            text3.setText("Salt and pepper, to taste");
            //Ingredients4
            text4.setText("");
            //Ingredients5
            text5.setText("");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }

        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}
