package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PizzaRoll_Recipe extends FastFoodTemplate implements ActionListener {

    public PizzaRoll_Recipe() {

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\PizzaRoll.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Pizza-Roll-Cover.jpg"));

        //Heading...............................
        heading.setText("Pizza Roll");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Refrigerated pizza crust tubes");
        //Ingredients2
        text2.setText("Ingredient two");
        //Ingredients3
        text3.setText("Garlic salt");
        //Ingredients4
        text4.setText("Shredded Mozzarella cheese");
        //Ingredients5
        text5.setText("Italian seasoning");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) Preheat oven to 425°F (218°C)" +
                "\n\n2) Dust a large surface with flour and roll out each pizza crust." +
                "\n\n3) Sprinkle garlic salt and Italian seasoning directly on each crust." +
                "\n\n4) Add the Mozzarella and Parmesan cheeses and diced pepperoni, spreading it within\n ½ inch of the edges of the crust." +
                "\n\n5) Starting with a short end, carefully roll crust into a tight log. " +
                "");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n\n\n6) Using a serrated knife or sharp pizza cutter, slice each roll into 1-inch sections."+
                    "\n\n7) Place pizza rolls on a lightly greased pan and bake for 10-12 mins\n or until golden brown." +
                    "\n\n 8) Serve immediately with marinara sauce for dipping");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Parmesan cheese");
            //Ingredients7
            text2.setText("Pepperoni");
            //Ingredients8
            text3.setText("Marinara sauce");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Preheat oven to 425°F (218°C)" +
                    "\n\n2) Dust a large surface with flour and roll out each pizza crust." +
                    "\n\n3) Sprinkle garlic salt and Italian seasoning directly on each crust." +
                    "\n\n4) Add the Mozzarella and Parmesan cheeses and diced pepperoni, spreading it within\n ½ inch of the edges of the crust." +
                    "\n\n5) Starting with a short end, carefully roll crust into a tight log. " +
                    "");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Refrigerated pizza crust tubes");
            //Ingredients2
            text2.setText("Ingredient two");
            //Ingredients3
            text3.setText("Garlic salt");
            //Ingredients4
            text4.setText("Shredded Mozzarella cheese");
            //Ingredients5
            text5.setText("Italian seasoning");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}

