package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pakoray_Recipe extends DesiFood_Template implements ActionListener {

    public Pakoray_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Pakory.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Pakory-Cover.jpg"));

        //Heading...............................
        heading.setText("Pakoray");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("2 cups Besan");
        //Ingredients2
        text2.setText("1 tablespoon crushed red pepper");
        //Ingredients3
        text3.setText("¾ teaspoon salt");
        //Ingredients4
        text4.setText("½ teaspoon baking powder");
        //Ingredients5
        text5.setText("1 green chilii pepper, sliced");

        //Steps to prepare Dish..................
        Text_area.setText("1.Fill an 8-inch cast-iron skillet half-way up with oil. \n" +
                "\n2.Heat the oil to 360-375ºF.\n" +
                "\n3.In a large bowl, mix together the besan, red chili flakes, salt, baking powder, \n" +
                "sliced chilli pepper, cilantro, and sliced onion.\n" +
                "\n4.Slowly add in the water, while mixing with a wooden spoon or your hands.\n" +
                "\n5.Vigorously mix for a couple of seconds.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("1.Fill an 8-inch cast-iron skillet half-way up with oil. \n" +
                    "\n2.Heat the oil to 360-375ºF.\n" +
                    "\n3.In a large bowl, mix together the besan, red chili flakes, salt, baking powder, \n" +
                    "sliced chilli pepper, cilantro, and sliced onion.\n" +
                    "\n4.Slowly add in the water, while mixing with a wooden spoon or your hands.\n" +
                    "\n5.Vigorously mix for a couple of seconds.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("½ cup Cilantro chopped leaves");
            //Ingredients2
            text2.setText("Ingredient eight");
            //Ingredients3
            text3.setText("1 yellow sliced onion");
            //Ingredients4
            text4.setText("1 cup luke-warm water");
            //Ingredients5
            text5.setText("Oil");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1.Fill an 8-inch cast-iron skillet half-way up with oil. \n" +
                    "\n2.Heat the oil to 360-375ºF.\n" +
                    "\n3.In a large bowl, mix together the besan, red chili flakes, salt, baking powder, \n" +
                    "sliced chilli pepper, cilantro, and sliced onion.\n" +
                    "\n4.Slowly add in the water, while mixing with a wooden spoon or your hands.\n" +
                    "\n5.Vigorously mix for a couple of seconds.");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("2 cups Besan");
            //Ingredients2
            text2.setText("1 tablespoon crushed red pepper");
            //Ingredients3
            text3.setText("¾ teaspoon salt");
            //Ingredients4
            text4.setText("½ teaspoon baking powder");
            //Ingredients5
            text5.setText("1 green chilii pepper, sliced");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
