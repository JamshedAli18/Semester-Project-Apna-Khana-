package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Masoor_Recipe extends DesiFood_Template implements ActionListener {

    public Masoor_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Masoor Daal.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Masoor-Dall-Cover.jpg"));

        //Heading...............................
        heading.setText("Masoor Daal");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Masoor lentil 1 cup");
        //Ingredients2
        text2.setText("Moong lentil ½ cup");
        //Ingredients3
        text3.setText("Whole cumin  ½ tsp");
        //Ingredients4
        text4.setText("Chopped Garlic 2 tsp");
        //Ingredients5
        text5.setText("Red chili powder 1tsp");

        //Steps to prepare Dish..................
        Text_area.setText("\n1. Cook 1 cup Masoor lentil, \n" +
                "\n2. ½ cup Moong lentil with 1tsp salt, \n" +
                "\n3. 1tsp Red chili powder, ½ tsp Turmeric powder and water.\n" +
                "\n4. Now add 1 tsp of tara garam masala, \n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5. 3-4 green chilies and ¼ cup of green coriander.\n" +
                    "\n6. For tarka melt 2 tbsp of butter, \n" +
                    "\n7. 4 tbsp oil, 2 tsp of garlic, 1/2 tsp of whole cumin seeds.\n" +
                    "\n8. Before serving pour prepared mixture over dal");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Turmeric powder ½ tsp");
            //Ingredients2
            text2.setText("Salt 1tsp");
            //Ingredients3
            text3.setText("Tara garam masala 1tsp");
            //Ingredients4
            text4.setText("Green chilies 3-4");
            //Ingredients5
            text5.setText("Oil 4tbsp");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1. Cook 1 cup Masoor lentil, \n" +
                    "\n2. ½ cup Moong lentil with 1tsp salt, \n" +
                    "\n3. 1tsp Red chili powder, ½ tsp Turmeric powder and water.\n" +
                    "\n4. Now add 1 tsp of tara garam masala, \n");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Masoor lentil 1 cup");
            //Ingredients2
            text2.setText("Moong lentil ½ cup");
            //Ingredients3
            text3.setText("Whole cumin  ½ tsp");
            //Ingredients4
            text4.setText("Chopped Garlic 2 tsp");
            //Ingredients5
            text5.setText("Red chili powder 1tsp");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
