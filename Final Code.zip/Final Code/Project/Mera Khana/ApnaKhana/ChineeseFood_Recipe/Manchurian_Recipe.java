package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import ApnaKhana.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Manchurian_Recipe extends ChineeseFood_Template implements ActionListener {

    public Manchurian_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Manchurian.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Manchurian-Cover.jpg"));

        //Heading...............................
        heading.setText("Manchurian");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Chicken ½ kg cut in cubes");
        //Ingredients2
        text2.setText("Salt 1 tsp.");
        //Ingredients3
        text3.setText("Garlic 1 tbsp");
        //Ingredients4
        text4.setText("I Black pepper ½ tsp");
        //Ingredients5
        text5.setText("Chili flakes 1 tbsp.");

        //Steps to prepare Dish..................
        Text_area.setText("1) Pin a bowl take chicken and add salt, garlic, black pepper, chili flakes, soya sauce  " +
                "\n  and mix well. Add corn flour and egg and mix well. \n\n2) Deep fry chicken cubes in a wok and set aside." +
                "\n\n3) For gravy, heat oil, add ginger and garlic saute and add green chili and spring\n" +
                "  onion and saute for 30 seconds. Add capsicum, onion and saute for 30 seconds." +
                "\n Add salt, red chili, vinegar, soya sauce, Knorr Tomato Ketchup, Knorr Chili Garlic" +
                "\n Sauce, sugar and paprika and mix. \n\n4)  Bake the coated pieces for 10 minutes in center of oven until chicken" +
                "\n  is turned crisp.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("5) Add 1 cup water stir and add mixture of water and corn flour mix until gravy" +
                    "\n  thickens. Dish out and serve with Chinese vegetable rice or garlic rice.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Soya sauce 1 &1/2 tbsp.");
            //Ingredients7
            text2.setText(" Corn flour 4 tbsp.");
            //Ingredients8
            text3.setText("Egg 1");
            //Ingredients9
            text4.setText("Oil for frying chicken");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) Pin a bowl take chicken and add salt, garlic, black pepper, chili flakes, soya sauce  " +
                    "\n  and mix well. Add corn flour and egg and mix well. \n\n2) Deep fry chicken cubes in a wok and set aside." +
                    "\n\n3) For gravy, heat oil, add ginger and garlic saute and add green chili and spring\n" +
                    "  onion and saute for 30 seconds. Add capsicum, onion and saute for 30 seconds." +
                    "\n Add salt, red chili, vinegar, soya sauce, Knorr Tomato Ketchup, Knorr Chili Garlic" +
                    "\n Sauce, sugar and paprika and mix. \n\n4)  Bake the coated pieces for 10 minutes in center of oven until chicken" +
                    "\n  is turned crisp.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Chicken ½ kg cut in cubes");
            //Ingredients2
            text2.setText("Salt 1 tsp.");
            //Ingredients3
            text3.setText("Garlic 1 tbsp");
            //Ingredients4
            text4.setText("I Black pepper ½ tsp");
            //Ingredients5
            text5.setText("Chili flakes 1 tbsp.");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}

