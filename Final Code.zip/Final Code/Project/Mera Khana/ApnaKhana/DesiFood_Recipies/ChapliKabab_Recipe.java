package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChapliKabab_Recipe extends DesiFood_Template implements ActionListener {

    public ChapliKabab_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Capli Kabab.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\chapli-kabab-Cover.jpg"));

        //Heading...............................
        heading.setText("Chapli Kabab");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Beef mince ( ½ kg )");
        //Ingredients2
        text2.setText("Tomatoes ( 2 )");
        //Ingredients3
        text3.setText("Onion ( 2 )");
        //Ingredients4
        text4.setText("Green chilies ( 5 )");
        //Ingredients5
        text5.setText("White butter ( 2 tbsp )");

        //Steps to prepare Dish..................
        Text_area.setText("\n1. In a bowl mix together ½ kg mince, 3 tbsp gram flour, 2 tbsp \n" +
                "crushed coriander, 2 tbsp pomegranate seeds, 2 tbsp crushed red \n" +
                "pepper, 1 tbsp turmeric powder, 1 tbsp all spice powder and salt to taste.\n" +
                "\n2. Finely chop 2 tomatoes, 1 onion, 5 green chilies and ¼ bunch of coriander leaves.\n" +
                "\n3. Add chopped vegetables to the mince mixture.\n" +
                "\n4. Then add 1 egg and 2 tbsp butter.\n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

        }
        @Override
        public void actionPerformed(ActionEvent e) {

            if(e.getSource()==Next_btn){

                Text_area.setText("\n5. Mix very well.\n" +
                        "\n6. Form large patties with the mince mixture.\n" +
                        "\n7. Then fry in a large griddle until golden brown.");

                //Ingredients..........................
                text.setText("Ingredients");
                //Ingredients1
                text1.setText("Gram flour ( 3 tbsp )");
                //Ingredients2
                text2.setText("Egg ( 1 )");
                //Ingredients3
                text3.setText("All spice powder ( 1 tbsp )");
                //Ingredients4
                text4.setText("Salt ( to taste )");
                //Ingredients5
                text5.setText("Oil ( ½ liter )");

                button.remove(Next_btn);
                button.add(Previous_btn);

            }else if(e.getSource()==Previous_btn){

                Text_area.setText("\n1. In a bowl mix together ½ kg mince, 3 tbsp gram flour, 2 tbsp \n" +
                        "crushed coriander, 2 tbsp pomegranate seeds, 2 tbsp crushed red \n" +
                        "pepper, 1 tbsp turmeric powder, 1 tbsp all spice powder and salt to taste.\n" +
                        "\n2. Finely chop 2 tomatoes, 1 onion, 5 green chilies and ¼ bunch of coriander leaves.\n" +
                        "\n3. Add chopped vegetables to the mince mixture.\n" +
                        "\n4. Then add 1 egg and 2 tbsp butter.\n");

                text.setText("Ingredients");
                //Ingredients1
                text1.setText("Beef mince ( ½ kg )");
                //Ingredients2
                text2.setText("Tomatoes ( 2 )");
                //Ingredients3
                text3.setText("Onion ( 2 )");
                //Ingredients4
                text4.setText("Green chilies ( 5 )");
                //Ingredients5
                text5.setText("White butter ( 2 tbsp )");

                button.add(Next_btn);
                button.remove(Previous_btn);
            }
            //Previous Frame Button
            if (e.getSource() == PreviousFrame_Button) {

                frame.dispose();
                Desi_Food obj = new Desi_Food();

            }
    }
}
