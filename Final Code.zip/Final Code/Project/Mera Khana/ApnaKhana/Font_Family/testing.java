package ApnaKhana.Font_Family;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
class pane{
    pane(){
        JFrame frame = new JFrame();
        JTextArea Text_Area = new JTextArea();
        JScrollPane scroller = new JScrollPane(Text_Area);
//        JPanel panel1 = new JPanel();
//        JPanel panel2 = new JPanel();
       Text_Area.setText ("Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan\n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n " +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                "Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan \n" +
                " Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan Ahsan ");
//        panel2.add(Text_Area);
//        panel1.add(panel2);
//        panel1.add(scroller);
//        panel1.setSize(500 , 200);
        Text_Area.setBounds(100,200,350,400);
        frame.setSize(500 , 500 );
//        frame.add(panel1);
//        frame.add(Text_Area);
        scroller.setBounds(100,200,350,400);
        frame.getContentPane().add(scroller);
        frame.setVisible(true);



    }


}
public class testing {
    public static void main(String[] args) {
        pane obj = new pane();
    }
}
