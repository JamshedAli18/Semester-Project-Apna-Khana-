package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MePoTofu_Recipe extends ChineeseFood_Template implements ActionListener {
    public MePoTofu_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Me po tofu.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\-Cover.jpg"));

        //Heading...............................
        heading.setText("Me Po Tofu");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("450g tofu");
        //Ingredients2
        text2.setText("3 tbsp groundnut oil");
        //Ingredients3
        text3.setText("100g pork mince");
        //Ingredients4
        text4.setText("2 tbsp Sichuan chilli bean paste");
        //Ingredients5
        text5.setText("1½ tbsp fermented black beans , rinsed");

        //Steps to prepare Dish..................
        Text_area.setText("1) Cut the Tofu in small cubes and place in a bowl. Add the Salt and hot Water (90 C)." +
                "\n Soak the Tofu for 5 minutes and then drain." +
                "\n\n2) In a frying pan, on medium-high heat. Add the Dried Red Peppers and Sichuan\n" +
                " Peppercorns and fry for about 1 minute until fragrant. Then use a mortar and pestle" +
                "\n to grind the peppers." +
                "\n\n3) In a wok, add in Vegetable Oil, on medium-high heat. Then add the Ground Pork \n" +
                "and cook for about 2 minutes until the color changes to a light brown. " +
                "\n\n4) Add the Chili Bean Sauce and stir with the pork for about 30 seconds until" +
                "\n the pork is well coated.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("5) Add the Water and turn the heat down to medium-low. Add all Seasonings: " +
                    " \n  Salt, Chicken Bouillon, Sugar, and Dark Soy Sauce. Stir well." + "\n\n6) Add the Tofu and mix well with the sauce. Cook the Tofu for approximately 5 minutes" +
                    "\n  on medium-low heat." + "\n\n7) During the 5 minutes cooking time, add 3 tbsp of Starch Water one spoonful" +
                    "\n  at a time every 30 seconds." + "\n\n8) Before serving, add the ground Peppers, and chopped Green Onions for garnish.");
            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("2cm piece ginger");
            //Ingredients7
            text2.setText("3 garlic cloves , chopped");
            //Ingredients8
            text3.setText("200ml light chicken");
            //Ingredients9
            text4.setText("1 tsp cornflour");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) Cut the Tofu in small cubes and place in a bowl. Add the Salt and hot Water (90 C)." +
                    "\n Soak the Tofu for 5 minutes and then drain." +
                    "\n\n2) In a frying pan, on medium-high heat. Add the Dried Red Peppers and Sichuan\n" +
                    " Peppercorns and fry for about 1 minute until fragrant. Then use a mortar and pestle" +
                    "\n to grind the peppers." +
                    "\n\n3) In a wok, add in Vegetable Oil, on medium-high heat. Then add the Ground Pork \n" +
                    "and cook for about 2 minutes until the color changes to a light brown. " +
                    "\n\n4) Add the Chili Bean Sauce and stir with the pork for about 30 seconds until" +
                    "\n the pork is well coated.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("450g tofu");
            //Ingredients2
            text2.setText("3 tbsp groundnut oil");
            //Ingredients3
            text3.setText("100g pork mince");
            //Ingredients4
            text4.setText("2 tbsp Sichuan chilli bean paste");
            //Ingredients5
            text5.setText("1½ tbsp fermented black beans , rinsed");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}
