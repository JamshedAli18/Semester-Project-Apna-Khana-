package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SpicyTofu_Recipe extends ChineeseFood_Template implements ActionListener {

    public  SpicyTofu_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Spicy tofu.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Spicy-Tofu-Cover.jpg"));

        //Heading...............................
        heading.setText("Spicy Tofu");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("16 ounces extra-firm tofu, cut into 1/2-inch cubes");
        //Ingredients2
        text2.setText("1/2 cup orange juice");
        //Ingredients3
        text3.setText("1/3 cup vegetable stock");
        //Ingredients4
        text4.setText("1/4 cup soy sauce");
        //Ingredients5
        text5.setText("3 tablespoons honey");

        //Steps to prepare Dish..................
        Text_area.setText("1) Bake or sautée the tofu." +
                "\n\n2) Mix the sugar, soy sauce, gochujang, and vegetable stock or water in a bowl " +
                "\n  until well combined. Set aside." +
                "\n\n3) Heat 1 tbsp of oil in a skillet and cook the garlic and onion over medium-high " +
                "\n  heat until golden brown, stirring frequently. " +
                "\n\n4)  Incorporate the cooked tofu and the sauce, stir, and cook for about 5 minutes." +
                "\n\n5)  Serve your spicy tofu immediately.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("1) Bake or sautée the tofu." +
                    "\n\n2) Mix the sugar, soy sauce, gochujang, and vegetable stock or water in a bowl " +
                    "\n  until well combined. Set aside." +
                    "\n\n3) Heat 1 tbsp of oil in a skillet and cook the garlic and onion over medium-high " +
                    "\n  heat until golden brown, stirring frequently. " +
                    "\n\n4)  Incorporate the cooked tofu and the sauce, stir, and cook for about 5 minutes." +
                    "\n\n5)  Serve your spicy tofu immediately.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("2 teaspoons rice vinegar\n");
            //Ingredients7
            text2.setText("1/2 teaspoon garlic chili sauce, add more for a spicier sauce");
            //Ingredients8
            text3.setText("1 tablespoon cornstarch");
            //Ingredients9
            text4.setText("2 tablespoons water");
            //Ingredients10
            text5.setText("Black pepper, to taste");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn) {

            Text_area.setText("1) Bake or sautée the tofu." +
                    "\n\n2) Mix the sugar, soy sauce, gochujang, and vegetable stock or water in a bowl " +
                    "\n  until well combined. Set aside." +
                    "\n\n3) Heat 1 tbsp of oil in a skillet and cook the garlic and onion over medium-high " +
                    "\n  heat until golden brown, stirring frequently. " +
                    "\n\n4)  Incorporate the cooked tofu and the sauce, stir, and cook for about 5 minutes." +
                    "\n\n5)  Serve your spicy tofu immediately.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("16 ounces extra-firm tofu, cut into 1/2-inch cubes");
            //Ingredients2
            text2.setText("1/2 cup orange juice");
            //Ingredients3
            text3.setText("1/3 cup vegetable stock");
            //Ingredients4
            text4.setText("1/4 cup soy sauce");
            //Ingredients5
            text5.setText("3 tablespoons honey");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();

        }
    }
}
