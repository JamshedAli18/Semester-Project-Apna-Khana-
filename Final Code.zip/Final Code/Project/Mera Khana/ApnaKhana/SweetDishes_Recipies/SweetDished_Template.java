package ApnaKhana.SweetDishes_Recipies;

import javax.swing.*;
import java.awt.*;

public class SweetDished_Template {

    JFrame frame = new JFrame();
    JButton Next_btn = new JButton();
    JButton Previous_btn = new JButton();
    JButton PreviousFrame_Button = new JButton("Back");
    JLabel label2 = new JLabel();
    JLabel label1 = new JLabel();
    JPanel button = new JPanel();
    JLabel Background = new JLabel();
    JTextArea Text_area = new JTextArea();
    JLayeredPane layeredPane = new JLayeredPane();

    //heading
    JLabel heading = new JLabel();
    // Ingredients
    JLabel text = new JLabel();
    //1 Ingredients Text
    JLabel text1 = new JLabel();
    //2 Ingredients Text
    JLabel text2 = new JLabel();
    //3 Ingredients Text
    JLabel text3 = new JLabel();
    //4 Ingredients Text
    JLabel text4 = new JLabel();

    JLabel text5 = new JLabel();
    JLabel text6 = new JLabel();

    // Direction Text Setting
    JLabel Direction = new JLabel();
    SweetDished_Template(){

        //Background PanelImage
        // Small Image
        label2.setOpaque(true);
        label2.setBackground(new Color((float) 0, (float) 0, (float) 0, (float) 0.0));
        label2.setFocusable(false);
        label2.setBounds(40, 50, 600, 400);

        //Large Image
        label1.setBounds(0, 0, 1270, 250);
        label1.setOpaque(true);

        //Background Image
        Background.setIcon(new ImageIcon("\\Light-Background.jpg"));
        Background.setBounds(0 , 0 , 1270 , 720);

        //LayeredPane for making the layer on both images
        layeredPane.setBounds(0, 0, 500, 500);
        layeredPane.add(label2);
        layeredPane.add(label1);
        layeredPane.add(Background);

        //Section Heaading
        heading.setBounds(70, 245, 400, 150);
        heading.setFont(new Font("Serif", Font.ITALIC, 30));
        heading.setForeground(Color.white);
        heading.setOpaque(false);

        // Ingredients Text Section
        text.setBounds(80, 290, 300, 200);
        text.setFont(new Font("Serif", Font.BOLD, 30));
        text.setForeground(Color.black);
        text.setOpaque(false);

        text1.setBounds(50, 330, 900, 200);
        text1.setFont(new Font("Serif", Font.PLAIN, 21));
        text1.setForeground(Color.black);

        text2.setBounds(50, 370, 900, 200);
        text2.setFont(new Font("Serif", Font.PLAIN, 21));
        text2.setForeground(Color.black);

        text3.setBounds(50, 410, 900, 200);
        text3.setFont(new Font("Serif", Font.PLAIN, 21));
        text3.setForeground(Color.black);

        text4.setBounds(50, 450, 900, 200);
        text4.setFont(new Font("Serif", Font.PLAIN, 21));
        text4.setForeground(Color.black);

        text5.setBounds(50, 490, 900, 200);
        text5.setFont(new Font("Serif", Font.PLAIN, 21));
        text5.setForeground(Color.black);

        Direction.setText("Steps To Prepare");
        Direction.setBounds(650, 230, 400, 150);
        Direction.setFont(new Font("Serif", Font.BOLD, 35));
        Direction.setForeground(Color.black);

        //Step to prepare the dish.....................
        Text_area.setFont(new Font("San Sarif" , Font.PLAIN , 16));
        Text_area.setBounds(650, 340, 600, 500);
        Text_area.setOpaque(false);
        Text_area.setEditable(false);

        //next button.........................................
        Next_btn.setBounds(1100,600,100,50);
        Next_btn.setFocusable(false);

        //Previous button.....................................
        Previous_btn.setBounds(800,600,100,50);
        Previous_btn.setFocusable(false);

        //Both buttons added to the Panel.............
        button.add(Next_btn);
        button.setBounds(1100,600,100,50);
        button.setFocusable(false);
        button.setOpaque(false);
        button.setBackground(new Color((float) 0, (float) 0, (float) 0, (float) 0.3));

        //Previous Frame
        PreviousFrame_Button.setBounds(30,40,70,30);
        PreviousFrame_Button.setFocusable(false);

        //Favicon Section
        ImageIcon favicon = new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Favicon.png");
        frame.setIconImage(favicon.getImage());

        //adding components to frame
        frame.add(PreviousFrame_Button);
        frame.add(button);    //panel
        frame.add(heading);   //heading
        frame.add(text);
        frame.add(text1);
        frame.add(text2);
        frame.add(text3);
        frame.add(text4);
        frame.add(text5);
        frame.add(Direction);
        frame.add(Text_area);
        frame.add(layeredPane);
    }
}
