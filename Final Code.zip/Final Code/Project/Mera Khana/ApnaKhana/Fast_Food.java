package ApnaKhana;
import ApnaKhana.Recipies.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Fast_Food extends PreviousButton implements ActionListener {

    JPanel panel1 = new JPanel();
    JLabel Background = new JLabel();
    JLabel text = new JLabel();
    JLabel Fries_Image = new JLabel();
    JLabel Chicken_nuggets_Image = new JLabel();
    JLabel Burger_Image = new JLabel();
    JLabel Pizza_Image = new JLabel();
    JLabel Chicken_roll_Image = new JLabel();
    JLabel Pizza_roll_Image = new JLabel();
    JLabel Chicken_popeyes_Image = new JLabel();
    JLabel Chicken_sandwich_Image = new JLabel();
    JLabel Chicken_tenders_Image = new JLabel();
    JLabel Hash_browns_Image = new JLabel();
    JLabel Pasta_Image = new JLabel();
    JLabel Cheese_burger_Image = new JLabel();
    JFrame frame = new JFrame();
    JButton Fries = new JButton();
    JButton Chicken_nuggets = new JButton();
    JButton Burger = new JButton();
    JButton Pizza = new JButton();
    JButton Chicken_roll = new JButton();
    JButton Pizza_roll = new JButton();
    JButton Chicken_popeyes = new JButton();
    JButton Chicken_sandwich = new JButton();
    JButton Chicken_tenders = new JButton();
    JButton Hash_browns = new JButton();
    JButton Pasta = new JButton();
    JButton Cheese_burger = new JButton();

    public Fast_Food() {

        //Favicon setting
        ImageIcon favicon = new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Favicon.png");
        frame.setIconImage(favicon.getImage());

        //Background setting
        Background.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\Background.jpg"));
        Background.setBounds(0, 0, 1270, 720);

        //Background Overly setting
        panel1.setBackground(new Color((float) 0, (float) 0, (float) 0, (float) 0.7));
        panel1.setBounds(0, 0, 1270, 720);

        //Menu Heading
        text.setText("Menu");
        text.setFont(Magrib);
        text.setForeground(Color.black);
        text.setBounds(520, 20, 400, 100);

        //Fries Text Section
        Fries.setText("Fries");
        Fries.setFont(Asap);
        Fries.setForeground(Color.BLACK);
        Fries.setBounds(0, 140, 150, 150);
        Fries.setBackground(Color.BLUE);
        Fries.setOpaque(false);
        Fries.setContentAreaFilled(true);
        Fries.setBorderPainted(false);
        Fries.setFocusable(false);

        //Fries Image Section
        Fries_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\fries.png"));
        Fries_Image.setBounds(220, 150, 110, 130);
        Fries_Image.setOpaque(false);

        //Chicken nuggets Text Section
        Chicken_nuggets.setText("Nuggets");
        Chicken_nuggets.setFont(Asap);
        Chicken_nuggets.setForeground(Color.BLACK);
        Chicken_nuggets.setBounds(0, 270, 200, 150);
        Chicken_nuggets.setOpaque(false);
        Chicken_nuggets.setContentAreaFilled(false);
        Chicken_nuggets.setBorderPainted(false);
        Chicken_nuggets.setFocusable(false);

        //Chicken nuggets Image Section
        Chicken_nuggets_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\Chicken nugguts.png"));
        Chicken_nuggets_Image.setBounds(220, 280, 110, 130);
        Chicken_nuggets_Image.setOpaque(false);

        //Burger Text Section
        Burger.setText("Burger");
        Burger.setFont(Asap);
        Burger.setForeground(Color.BLACK);
        Burger.setBounds(-10, 400, 200, 150);
        Burger.setOpaque(false);
        Burger.setContentAreaFilled(false);
        Burger.setBorderPainted(false);
        Burger.setFocusable(false);

        //Burger Image Section
        Burger_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\burger.jpeg"));
        Burger_Image.setBounds(220, 410, 110, 130);
        Burger_Image.setOpaque(false);

        //Pizza Text Section
        Pizza.setText("Pizza");
        Pizza.setFont(Asap);
        Pizza.setForeground(Color.BLACK);
        Pizza.setBounds(-20, 530, 200, 150);
        Pizza.setOpaque(false);
        Pizza.setContentAreaFilled(false);
        Pizza.setBorderPainted(false);
        Pizza.setFocusable(false);

        //Pizza Image Section
        Pizza_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\pizza.png"));
        Pizza_Image.setBounds(220, 540, 110, 130);
        Pizza_Image.setOpaque(false);

        //Chicken_roll Text Section
        Chicken_roll.setText("Roll");
        Chicken_roll.setFont(Asap);
        Chicken_roll.setForeground(Color.BLACK);
        Chicken_roll.setBounds(300, 140, 260, 150);
        Chicken_roll.setOpaque(false);
        Chicken_roll.setContentAreaFilled(false);
        Chicken_roll.setBorderPainted(false);
        Chicken_roll.setFocusable(false);

        //Chicken_roll Image Section
        Chicken_roll_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\chicken roll.png"));
        Chicken_roll_Image.setBounds(630, 150, 110, 130);
        Chicken_roll_Image.setOpaque(false);

        //Pizza_roll Text Section
        Pizza_roll.setText("Pizza Roll");
        Pizza_roll.setFont(Asap);
        Pizza_roll.setForeground(Color.BLACK);
        Pizza_roll.setBounds(350, 270, 250, 150);
        Pizza_roll.setOpaque(false);
        Pizza_roll.setContentAreaFilled(false);
        Pizza_roll.setBorderPainted(false);
        Pizza_roll.setFocusable(false);

        //Pizza_roll Image Section
        Pizza_roll_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\pizza roll.png"));
        Pizza_roll_Image.setBounds(630, 280, 110, 130);
        Pizza_roll_Image.setOpaque(false);

        //Chicken_popeyes Text Section
        Chicken_popeyes.setText("Popeyes");
        Chicken_popeyes.setFont(Asap);
        Chicken_popeyes.setForeground(Color.BLACK);
        Chicken_popeyes.setBounds(350, 400, 230, 150);
        Chicken_popeyes.setOpaque(false);
        Chicken_popeyes.setContentAreaFilled(false);
        Chicken_popeyes.setBorderPainted(false);
        Chicken_popeyes.setFocusable(false);

        //Popeye Image Section
        Chicken_popeyes_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\Popeye.png"));
        Chicken_popeyes_Image.setBounds(630, 410, 110, 130);
        Chicken_popeyes_Image.setOpaque(false);


        //Chicken_sandwich Text Section
        Chicken_sandwich.setText("Sandwich");
        Chicken_sandwich.setFont(Asap);
        Chicken_sandwich.setForeground(Color.BLACK);
        Chicken_sandwich.setBounds(350, 530, 240, 150);
        Chicken_sandwich.setOpaque(false);
        Chicken_sandwich.setContentAreaFilled(false);
        Chicken_sandwich.setBorderPainted(false);
        Chicken_sandwich.setFocusable(false);

        //Chicken_sandwich Image Section
        Chicken_sandwich_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\Chicken sandwich.png"));
        Chicken_sandwich_Image.setBounds(630, 540, 110, 130);
        Chicken_sandwich_Image.setOpaque(false);

        //Chicken_tenders Text Section
        Chicken_tenders.setText("Tenders");
        Chicken_tenders.setFont(Asap);
        Chicken_tenders.setForeground(Color.BLACK);
        Chicken_tenders.setBounds(750, 140, 200, 150);
        Chicken_tenders.setOpaque(false);
        Chicken_tenders.setContentAreaFilled(false);
        Chicken_tenders.setBorderPainted(false);
        Chicken_tenders.setFocusable(false);

        //Chicken tenders Image Section
        Chicken_tenders_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\chicken tender.png"));
        Chicken_tenders_Image.setBounds(1080, 150, 110, 130);
        Chicken_tenders_Image.setOpaque(false);

        //Hash_browns Text Section
        Hash_browns.setText("Hash Browns");
        Hash_browns.setFont(Asap);
        Hash_browns.setForeground(Color.BLACK);
        Hash_browns.setBounds(760, 270, 290, 150);
        Hash_browns.setOpaque(false);
        Hash_browns.setContentAreaFilled(false);
        Hash_browns.setBorderPainted(false);
        Hash_browns.setFocusable(false);

        //Hash_browns Image Section
        Hash_browns_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\hash brown.png"));
        Hash_browns_Image.setBounds(1080, 280, 110, 130);
        Hash_browns_Image.setOpaque(false);

        //Pasta Text Section
        Pasta.setText("Pasta");
        Pasta.setFont(Asap);
        Pasta.setForeground(Color.BLACK);
        Pasta.setBounds(740, 400, 200, 150);
        Pasta.setOpaque(false);
        Pasta.setContentAreaFilled(false);
        Pasta.setBorderPainted(false);
        Pasta.setFocusable(false);

        //Pasta Image Section
        Pasta_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\pasta.png"));
        Pasta_Image.setBounds(1080, 410, 110, 130);
        Pasta_Image.setOpaque(false);

        //Cheese_burger Text Section
        Cheese_burger.setText("Cheese Burger");
        Cheese_burger.setFont(Asap);
        Cheese_burger.setForeground(Color.BLACK);
        Cheese_burger.setBounds(770, 530, 290, 150);
        Cheese_burger.setOpaque(false);
        Cheese_burger.setContentAreaFilled(false);
        Cheese_burger.setBorderPainted(false);
        Cheese_burger.setFocusable(false);

        //Cheese_burger Image Section
        Cheese_burger_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Fast Food\\cheese burgur.png"));
        Cheese_burger_Image.setBounds(1080, 540, 110, 130);
        Cheese_burger_Image.setOpaque(false);

        //Adding Buttons Functionalties......................
        Fries.addActionListener(this);
        Chicken_nuggets.addActionListener(this);
        Burger.addActionListener(this);
        Pizza.addActionListener(this);
        Chicken_roll.addActionListener(this);
        Pizza_roll.addActionListener(this);
        Chicken_popeyes.addActionListener(this);
        Chicken_sandwich.addActionListener(this);
        Chicken_tenders.addActionListener(this);
        Hash_browns.addActionListener(this);
        Pasta.addActionListener(this);
        Cheese_burger.addActionListener(this);

        //Back Buttons
        Previous_frame.addActionListener(this);

        //Adding in Frame Section
        frame.add(text);
        frame.add(Fries);
        frame.add(Fries_Image);
        frame.add(Chicken_nuggets);
        frame.add(Chicken_nuggets_Image);
        frame.add(Burger);
        frame.add(Burger_Image);
        frame.add(Chicken_roll);
        frame.add(Chicken_roll_Image);
        frame.add(Pizza_roll);
        frame.add(Pizza_roll_Image);
        frame.add(Chicken_popeyes);
        frame.add(Chicken_popeyes_Image);
        frame.add(Chicken_sandwich);
        frame.add(Chicken_sandwich_Image);
        frame.add(Chicken_tenders);
        frame.add(Chicken_tenders_Image);
        frame.add(Hash_browns);
        frame.add(Hash_browns_Image);
        frame.add(Pasta);
        frame.add(Pasta_Image);
        frame.add(Cheese_burger);
        frame.add(Cheese_burger_Image);
        frame.add(Pizza);
        frame.add(Pizza_Image);
        frame.add(Previous_frame);
        frame.add(Background);
        frame.setSize(1270, 720);
        frame.setVisible(true);
        frame.setLayout(null);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        //giving instructions.....................
        if(e.getSource()==Fries){

            frame.dispose();
            FriesRecipe obj = new FriesRecipe();

        }else if(e.getSource()==Chicken_nuggets){

            frame.dispose();
            Chicken_Nuggets obj = new Chicken_Nuggets();

        }else if(e.getSource()==Burger){

            frame.dispose();
            Burger_Recipe obj = new Burger_Recipe();

        }else if(e.getSource()==Pizza){

            frame.dispose();
            Pizza_Recipe obj = new Pizza_Recipe();

        }else if(e.getSource()==Chicken_roll){

            frame.dispose();
            Roll_Recipe obj = new Roll_Recipe();

        }else if(e.getSource()==Pizza_roll){

            frame.dispose();
            PizzaRoll_Recipe obj = new PizzaRoll_Recipe();

        }else if(e.getSource()==Chicken_popeyes){

            frame.dispose();
            Popeyes_Recipe obj = new Popeyes_Recipe();

        }else if(e.getSource()==Chicken_sandwich){

            frame.dispose();
            Sandwich_Recipe obj = new Sandwich_Recipe();

        }else if(e.getSource()==Chicken_tenders){

            frame.dispose();
            Tenders_Recipe obj = new Tenders_Recipe();

        }else if(e.getSource()==Hash_browns){

            frame.dispose();
            HashBrowns_Recipe obj = new HashBrowns_Recipe();

        }else if(e.getSource()==Pasta){

            frame.dispose();
            Pasta_Recipe obj = new Pasta_Recipe();

        }else if(e.getSource()==Cheese_burger){

            frame.dispose();
            Cheese_Burger_Recipe obj = new Cheese_Burger_Recipe();

        }else if(e.getSource()==Previous_frame){

            frame.dispose();
            Categories Main_Page = new Categories();

        }
    }
}
