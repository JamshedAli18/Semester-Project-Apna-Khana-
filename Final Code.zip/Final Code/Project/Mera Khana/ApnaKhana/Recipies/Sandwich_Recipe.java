package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sandwich_Recipe extends FastFoodTemplate implements ActionListener {

    public Sandwich_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Sandwich.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Sandwich-Cover.jpg"));

        //Heading...............................
        heading.setText("Sandwich");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 tablespoon olive oil");
        //Ingredients2
        text2.setText("3/4 pound boneless, skinless chicken breast");
        //Ingredients3
        text3.setText("1/4 teaspoon kosher salt");
        //Ingredients4
        text4.setText("1/4 teaspoon ground black pepper");
        //Ingredients5
        text5.setText("1/2 teaspoon onion powder");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) In a large skillet add the olive oil and heat until hot" +
                "\n\n2) Add the chicken, salt, pepper, onion powder, and oregano to the skillet and " +
                "\ncook over medium heat until the chicken is cooked through" +
                "\n but isn’t browned yet."  +
                "\n\n3) Move the chicken over to one side of the skillet and" +
                "\nturn the heat up to medium-high" +
                "\n\n4) Add the onions and peppers to the empty side of the skillet and cook" +
                "\nfor 3-4 minutes or until they soften.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5) Stir in the garlic with the onions and peppers. Cook for an additional minute." +
                    "\n\n6) Pre-heat the oven to broil." +
                    "\n\n7) Divide the chicken mixture and place it on the bottom half of each bun." +
                    "\nPlace two slices of cheese over the chicken on each bun." +
                    "\n\n8)Broil the sandwiches open-faced for a minute or two until the " +
                    "\n cheese is melted but not yet brown." +
                    "\n\n9) Add the top bun and serve immediately!");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1 small onion, thinly sliced");
            //Ingredients7
            text2.setText("1 small green bell pepper, thinly sliced");
            //Ingredients8
            text3.setText("1/2 cup water");
            //Ingredients9
            text4.setText("1 clove garlic, minced");
            //Ingredients10
            text5.setText("2 hoagie rolls");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) In a large skillet add the olive oil and heat until hot" +
                    "\n\n2) Add the chicken, salt, pepper, onion powder, and oregano to the skillet and " +
                    "\ncook over medium heat until the chicken is cooked through" +
                    "\n but isn’t browned yet."  +
                    "\n\n3) Move the chicken over to one side of the skillet and" +
                    "\nturn the heat up to medium-high" +
                    "\n\n4) Add the onions and peppers to the empty side of the skillet and cook" +
                    "\nfor 3-4 minutes or until they soften.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 tablespoon olive oil");
            //Ingredients2
            text2.setText("3/4 pound boneless, skinless chicken breast");
            //Ingredients3
            text3.setText("1/4 teaspoon kosher salt");
            //Ingredients4
            text4.setText("1/4 teaspoon ground black pepper");
            //Ingredients5
            text5.setText("1/2 teaspoon onion powder");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}
