package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GolGappay_Recipe extends DesiFood_Template implements ActionListener{

    public GolGappay_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Gol Gappy.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Gol-Gappy-Cover.jpg"));

        //Heading...............................
        heading.setText("Gol Gapay");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("1 cup atta");
        //Ingredients2
        text2.setText("1 1/2 cups suji");
        //Ingredients3
        text3.setText("1/2 tspn salt");
        //Ingredients4
        text4.setText("oil 2 tbspn");
        //Ingredients5
        text5.setText("Shaan Paani puri masala");

        //Steps to prepare Dish..................
        Text_area.setText("\n1. Oil for frying\n" +
                "\n2. Mix all the dough ingredients and make a hard dough.\n" +
                "\n3. Leave it covered for about 5 to 6 hours becasue suji takes " +
                "\ntime to swell up.\n" +
                "\n4. Take a small ball of the dough, roll it out not as thin as paper " +
                "\nand not as thick as a puri. \n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5. Cut into small rounds with the help of a cookie cutter.\n" +
                    "\n6. Fry these rounds, four five at a time, on slow fire. \n" +
                    "\n7. Don't remove as soon as it fluffs up. \n" +
                    "\n8.Wait for it to become crisp. \n");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Boiled Kala chana or chick pea can");
            //Ingredients2
            text2.setText("");
            //Ingredients3
            text3.setText("");
            //Ingredients4
            text4.setText("");
            //Ingredients5
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1. Oil for frying\n" +
                    "\n2. Mix all the dough ingredients and make a hard dough.\n" +
                    "\n3. Leave it covered for about 5 to 6 hours because suji takes " +
                    "\ntime to swell up.\n" +
                    "\n4. Take a small ball of the dough, roll it out not as thin as paper " +
                    "\nand not as thick as a puri. \n");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 cup atta");
            //Ingredients2
            text2.setText("1 1/2 cups suji");
            //Ingredients3
            text3.setText("1/2 tspn salt");
            //Ingredients4
            text4.setText("oil 2 tbspn");
            //Ingredients5
            text5.setText("Shaan Paani puri masala");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Desi_Food obj = new Desi_Food();
        }
    }
}
