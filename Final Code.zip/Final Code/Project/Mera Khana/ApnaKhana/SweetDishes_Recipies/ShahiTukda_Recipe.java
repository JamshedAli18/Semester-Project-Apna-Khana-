package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ShahiTukda_Recipe extends SweetDished_Template implements ActionListener {

    public ShahiTukda_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\ShahiTukda.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\ShahiTukda-Cover.jpg"));

        //Heading...............................
        heading.setText("Shahi Tukda");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("2½ cups Full Fat Milk");
        //Ingredients2
        text2.setText("1/4 cup Sweet Condensed Milk");
        //Ingredients3
        text3.setText("1 tablespoon Sugar");
        //Ingredients4
        text4.setText("4-5 Saffron strands (kesar)");
        //Ingredients5
        text5.setText("2 tablespoons grated Paneer or Khoya (mawa)");

        //Steps to prepare Dish..................
        Text_area.setText("1)  If you are using frozen paneer then thaw it before grating. In this recipe, sweet\n " +
                "condensed milk is used, which is easily available at any grocery store.\n\n" +
                "2)  Mix milk, sweet condensed milk, sugar and saffron strands in a thick-bottomed\n " +
                "pan and bring it to a boil on medium flame.\n\n3)  When it starts boiling, reduce flame " +
                "to low and boil until mixture turns thick and\n reduces to around 1½ cups, for around " +
                "10-15 minutes. Stir occasionally in between\n to prevent sticking.\n\n4)  " +
                "Add grated paneer and cardamom powder and mix well.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("5)  Turn off the flame and let rabadi cool at room temperature.\n\n" +
                    "6) Remove sides of bread slices and cut each into 4 triangles or 4 equal squares.\n\n" +
                    "7)  Brush bread squares with ghee on both sides. Heat a non-stick pan or tava and\n " +
                    "shallow fry them until bottom surface turns crispy and golden brown on low flame.\n\n" +
                    "8)  Flip them and shallow fry until another side turns crispy and golden brown.\n " +
                    "Transfer them to plate.\n\n9)  Arrange crisp fried bread pieces in a layer on serving plate." +
                    " Pour prepared\n rabadi over it.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1/4 teaspoon Cardamom");
            //Ingredients7
            text2.setText("4 White Bread Slices");
            //Ingredients8
            text3.setText("2-3 tablespoons Ghee");
            //Ingredients9
            text4.setText("1/2 tablespoon chopped Cashew Nuts");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1)  If you are using frozen paneer then thaw it before grating. In this recipe, " +
                    "sweet\n condensed milk is used, which is easily available at any grocery store.\n\n2) " +
                    " Mix milk, sweet condensed milk, sugar and saffron strands in a thick-bottomed\n" +
                    " pan and bring it to a boil on medium flame.\n\n3)  When it starts boiling, reduce " +
                    "flame to low and boil until mixture turns thick and\n reduces to around 1½ cups, " +
                    "for around 10-15 minutes. Stir occasionally in between\n to prevent sticking.\n\n" +
                    "4)  Add grated paneer and cardamom powder and mix well.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("2½ cups Full Fat Milk");
            //Ingredients2
            text2.setText("1/4 cup Sweet Condensed Milk");
            //Ingredients3
            text3.setText("1 tablespoon Sugar");
            //Ingredients4
            text4.setText("4-5 Saffron strands (kesar)");
            //Ingredients5
            text5.setText("2 tablespoons grated Paneer or Khoya (mawa)");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {
            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();
        }
    }
}
