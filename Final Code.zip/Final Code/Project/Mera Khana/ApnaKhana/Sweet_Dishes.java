package ApnaKhana;
import ApnaKhana.SweetDishes_Recipies.*;

import javax.swing.*;
import  java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Sweet_Dishes extends PreviousButton implements ActionListener {

    JFrame frame = new JFrame();
    JPanel Background_Overly = new JPanel();
    JButton Ghulab_Jamun = new JButton();
    JButton Suji_Ka_Halwa = new JButton();
    JButton Sewaiyaan = new JButton();
    JButton Sheer_Khurma = new JButton();
    JButton Jalebi = new JButton();
    JButton Custard = new JButton();
    JButton Cake = new JButton();
    JButton Shahi_Tukre = new JButton();
    JButton Rabri_Doodh = new JButton();
    JButton Falooda = new JButton();
    JButton Gajreela = new JButton();
    JButton Sohan_Halwa = new JButton();
    JLabel Backgorund = new JLabel();
    JLabel Heading_Text = new JLabel();
    JLabel Ghulab_Jamun_Image = new JLabel();
    JLabel Suji_Ka_Halwa_Image = new JLabel();
    JLabel Sewaiyaan_Image = new JLabel();
    JLabel Sheer_Khurma_Image = new JLabel();
    JLabel Jalebi_Image = new JLabel();
    JLabel Custard_Image = new JLabel();
    JLabel Cake_Image = new JLabel();
    JLabel Rabri_Doodh_Image = new JLabel();
    JLabel Falooda_Image = new JLabel();
    JLabel Gajreela_Image = new JLabel();
    JLabel Sohan_Halwa_Image = new JLabel();
    JLabel Shahi_Tukre_Image = new JLabel();

   public Sweet_Dishes(){

        //Favicon
        ImageIcon favicon = new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Favicon.png");
        frame.setIconImage(favicon.getImage());

        //Background
        Backgorund.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Background.jpg"));
        Backgorund.setBounds(0, 0, 1270, 720);

        //Background Overly
        Background_Overly.setBackground(new Color((float) 0, (float) 0, (float) 0, (float) 0.7));
        Background_Overly.setBounds(0, 0, 1270, 720);

        //Menu Heading
        Heading_Text.setText("Menu");
        Heading_Text.setFont(Magrib);
        Heading_Text.setForeground(Color.black);
        Heading_Text.setBounds(520, 20, 400, 100);

        //Ghulab Jamun Text Section
        Ghulab_Jamun.setText("Ghulab Jamun");
        Ghulab_Jamun.setFont(Asap);
        Ghulab_Jamun.setForeground(Color.BLACK);
        Ghulab_Jamun.setBounds(0, 140, 290, 150);
        Ghulab_Jamun.setOpaque(false);
        Ghulab_Jamun.setContentAreaFilled(false);
        Ghulab_Jamun.setBorderPainted(false);
        Ghulab_Jamun.setFocusable(false);

        //Ghulab Jamun Image Section
        Ghulab_Jamun_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Gulaab_jamun.png"));
        Ghulab_Jamun_Image.setBounds(287, 150, 160, 130);
        Ghulab_Jamun_Image.setOpaque(false);

        //Suji Ka Halwa Text Section
        Suji_Ka_Halwa.setText("Suji Ka Halwa");
        Suji_Ka_Halwa.setFont(Asap);
        Suji_Ka_Halwa.setForeground(Color.BLACK);
        Suji_Ka_Halwa.setBounds(-5, 270, 290, 150);
        Suji_Ka_Halwa.setOpaque(false);
        Suji_Ka_Halwa.setContentAreaFilled(false);
        Suji_Ka_Halwa.setBorderPainted(false);
        Suji_Ka_Halwa.setFocusable(false);

        //Suji Ka Halwa Image Section
        Suji_Ka_Halwa_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Suji_ka_hawla.png"));
        Suji_Ka_Halwa_Image.setBounds(287, 280, 120, 130);
        Suji_Ka_Halwa_Image.setOpaque(false);

        //Sewaiyaan Text Section
        Sewaiyaan.setText("Sewaiyaan");
        Sewaiyaan.setFont(Asap);
        Sewaiyaan.setForeground(Color.BLACK);
        Sewaiyaan.setBounds(5, 400, 230, 150);
        Sewaiyaan.setOpaque(false);
        Sewaiyaan.setContentAreaFilled(false);
        Sewaiyaan.setBorderPainted(false);
        Sewaiyaan.setFocusable(false);

        //Sewaiyaan Image Section
        Sewaiyaan_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Sawaiyan.png"));
        Sewaiyaan_Image.setBounds(290, 410, 150, 130);
        Sewaiyaan_Image.setOpaque(false);

        //Sheer Khurma Text Section
        Sheer_Khurma.setText("Sheer Khurma");
        Sheer_Khurma.setFont(Asap);
        Sheer_Khurma.setForeground(Color.BLACK);
        Sheer_Khurma.setBounds(2, 530, 290, 150);
        Sheer_Khurma.setOpaque(false);
        Sheer_Khurma.setContentAreaFilled(false);
        Sheer_Khurma.setBorderPainted(false);
        Sheer_Khurma.setFocusable(false);

        //Sheer Khurma Image Section
        Sheer_Khurma_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Sheer_khurma.png"));
        Sheer_Khurma_Image.setBounds(289, 540, 310, 130);
        Sheer_Khurma_Image.setOpaque(false);

        //Jalebi Text Section
        Jalebi.setText("Jalebi");
        Jalebi.setFont(Asap);
        Jalebi.setForeground(Color.BLACK);
        Jalebi.setBounds(350, 140, 290, 150);
        Jalebi.setOpaque(false);
        Jalebi.setContentAreaFilled(false);
        Jalebi.setBorderPainted(false);
        Jalebi.setFocusable(false);

        //Jalebi Image Section
        Jalebi_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Galeebi.png"));
        Jalebi_Image.setBounds(650, 150, 120, 130);
        Jalebi_Image.setOpaque(false);

        //Custard Text Section
        Custard.setText("Custard");
        Custard.setFont(Asap);
        Custard.setForeground(Color.BLACK);
        Custard.setBounds(360, 270, 290, 150);
        Custard.setOpaque(false);
        Custard.setContentAreaFilled(false);
        Custard.setBorderPainted(false);
        Custard.setFocusable(false);

        //Custard Image Section
        Custard_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Custard.png"));
        Custard_Image.setBounds(650, 280, 130, 130);
        Custard_Image.setOpaque(false);

        //Cake Text Section
        Cake.setText("Cake");
        Cake.setFont(Asap);
        Cake.setForeground(Color.BLACK);
        Cake.setBounds(368, 400, 230, 150);
        Cake.setOpaque(false);
        Cake.setContentAreaFilled(false);
        Cake.setBorderPainted(false);
        Cake.setFocusable(false);

        //Cake Image Section
        Cake_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Chocolate_cake.png"));
        Cake_Image.setBounds(650, 410, 130, 130);
        Cake_Image.setOpaque(false);

        //Shahi Tukre Text Section
        Shahi_Tukre.setText("Shahi Tukre");
        Shahi_Tukre.setFont(Asap);
        Shahi_Tukre.setForeground(Color.BLACK);
        Shahi_Tukre.setBounds(390, 530, 290, 150);
        Shahi_Tukre.setOpaque(false);
        Shahi_Tukre.setContentAreaFilled(false);
        Shahi_Tukre.setBorderPainted(false);
        Shahi_Tukre.setFocusable(false);

        //Shahi_tudre Image Section
        Shahi_Tukre_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Shahi_tudre.png"));
        Shahi_Tukre_Image.setBounds(650, 540, 130, 130);
        Shahi_Tukre_Image.setOpaque(false);


        //Rabri Doodh Text Section
        Rabri_Doodh.setText("Rabri Doodh");
        Rabri_Doodh.setFont(Asap);
        Rabri_Doodh.setForeground(Color.BLACK);
        Rabri_Doodh.setBounds(800, 140, 290, 150);
        Rabri_Doodh.setOpaque(false);
        Rabri_Doodh.setContentAreaFilled(false);
        Rabri_Doodh.setBorderPainted(false);
        Rabri_Doodh.setFocusable(false);

        //Rabri Doodh Image Section
        Rabri_Doodh_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Doodh_rabri.png"));
        Rabri_Doodh_Image.setBounds(1100, 150, 200, 130);
        Rabri_Doodh_Image.setOpaque(false);

        //Falooda Text Section
        Falooda.setText("Falooda");
        Falooda.setFont(Asap);
        Falooda.setForeground(Color.BLACK);
        Falooda.setBounds(760, 270, 290, 150);
        Falooda.setOpaque(false);
        Falooda.setContentAreaFilled(false);
        Falooda.setBorderPainted(false);
        Falooda.setFocusable(false);

        //Falooda Image Section
        Falooda_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Falooda.png"));
        Falooda_Image.setBounds(1100, 280, 300, 130);
        Falooda_Image.setOpaque(false);

        //Gajreela Text Section
        Gajreela.setText("Gajreela");
        Gajreela.setFont(Asap);
        Gajreela.setForeground(Color.BLACK);
        Gajreela.setBounds(790, 400, 230, 150);
        Gajreela.setOpaque(false);
        Gajreela.setContentAreaFilled(false);
        Gajreela.setBorderPainted(false);
        Gajreela.setFocusable(false);

        //Gajreela Image Section
        Gajreela_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Gajreela.png"));
        Gajreela_Image.setBounds(1100, 410, 200, 130);
        Gajreela_Image.setOpaque(false);

        //Sohan Halwa Text Section
        Sohan_Halwa.setText("Sohan Halwa");
        Sohan_Halwa.setFont(Asap);
        Sohan_Halwa.setForeground(Color.BLACK);
        Sohan_Halwa.setBounds(795, 530, 290, 150);
        Sohan_Halwa.setOpaque(false);
        Sohan_Halwa.setContentAreaFilled(false);
        Sohan_Halwa.setBorderPainted(false);
        Sohan_Halwa.setFocusable(false);

        //Sohan Halwa Image Section
        Sohan_Halwa_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Sweet Dishes\\Sohan_halwa.png"));
        Sohan_Halwa_Image.setBounds(1100, 540, 160, 130);
        Sohan_Halwa_Image.setOpaque(false);

        //Adding Buttons Functionalties......................
        Ghulab_Jamun.addActionListener(this);
        Suji_Ka_Halwa.addActionListener(this);
        Sewaiyaan.addActionListener(this);
        Sheer_Khurma.addActionListener(this);
        Jalebi.addActionListener(this);
        Custard.addActionListener(this);
        Cake.addActionListener(this);
        Shahi_Tukre.addActionListener(this);
        Rabri_Doodh.addActionListener(this);
        Falooda.addActionListener(this);
        Gajreela.addActionListener(this);
        Sohan_Halwa.addActionListener(this);

        //Button for returning to previous frame
        Previous_frame.addActionListener(this);

        // Adding in Frame Section
        frame.setVisible(true);
        frame.add(Heading_Text);
        frame.add(Ghulab_Jamun);
        frame.add(Ghulab_Jamun_Image);
        frame.add(Suji_Ka_Halwa);
        frame.add(Suji_Ka_Halwa_Image);
        frame.add(Sewaiyaan);
        frame.add(Sewaiyaan_Image);
        frame.add(Sheer_Khurma);
        frame.add(Jalebi);
        frame.add(Jalebi_Image);
        frame.add(Custard);
        frame.add(Custard_Image);
        frame.add(Cake);
        frame.add(Cake_Image);
        frame.add(Shahi_Tukre);
        frame.add(Shahi_Tukre_Image);
        frame.add(Sheer_Khurma_Image);
        frame.add(Rabri_Doodh);
        frame.add(Rabri_Doodh_Image);
        frame.add(Falooda);
        frame.add(Falooda_Image);
        frame.add(Gajreela);
        frame.add(Gajreela_Image);
        frame.add(Sohan_Halwa);
        frame.add(Sohan_Halwa_Image);
        frame.add(Previous_frame);
        frame.setLayout(null);
       frame.add(Previous_frame);
        frame.add(Backgorund);
        frame.setSize(1270, 720);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        //giving instructions.....................
        if(e.getSource()==Ghulab_Jamun){

            frame.dispose();
            GulabJamun_Recipe obj = new GulabJamun_Recipe();

        }else if(e.getSource()==Suji_Ka_Halwa){

            frame.dispose();
            SujiHalwa_Recipe obj = new SujiHalwa_Recipe();

        }else if(e.getSource()==Sewaiyaan){

            frame.dispose();
            Sewaiyaan_Recipe obj = new Sewaiyaan_Recipe();

        }else if(e.getSource()==Sheer_Khurma){

            frame.dispose();
            SheerKhurma_Recipe obj = new SheerKhurma_Recipe();

        }else if(e.getSource()==Jalebi){

            frame.dispose();
            Jalebi_Recipe obj = new Jalebi_Recipe();

        }else if(e.getSource()==Custard){

            frame.dispose();
            Custard_Recipe obj = new Custard_Recipe();

        }else if(e.getSource()==Cake){

            frame.dispose();
            Cake_Recipe obj = new Cake_Recipe();

        }else if(e.getSource()==Shahi_Tukre){

            frame.dispose();
            ShahiTukda_Recipe obj = new ShahiTukda_Recipe();

        }else if(e.getSource()==Rabri_Doodh){

            frame.dispose();
            RabriDoodh_Recipe obj = new RabriDoodh_Recipe();

        }else if(e.getSource()==Falooda){

            frame.dispose();
            Falooda obj = new Falooda();

        }else if(e.getSource()==Gajreela){

            frame.dispose();
            Gajeral_Recipe obj = new Gajeral_Recipe();

        }else if(e.getSource()==Sohan_Halwa){

            frame.dispose();
            SohnHalwa obj = new SohnHalwa();

        }else if(e.getSource()==Previous_frame){

            frame.dispose();
            Categories Main_Page = new Categories();

        }
    }
}