package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GulabJamun_Recipe extends SweetDished_Template implements ActionListener {

    public GulabJamun_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\GulabJamun.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\GulabJamun-Cover.jpg"));

        //Heading...............................
        heading.setText("Gulab Jamun");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Lassa khoya 250 grams");
        //Ingredients2
        text2.setText("Baking soda 1 pinch");
        //Ingredients3
        text3.setText("Salt 1 pinch");
        //Ingredients4
        text4.setText("Flour 1/3 cup");
        //Ingredients5
        text5.setText("Egg ½");

        //Steps to prepare Dish..................
        Text_area.setText("1)  To make syrup, in a pan add water and sugar and cook until it becomes\n   " +
                "  a sticky syrup. Now turn off the flame and add kewra water, cardamom\n   " +
                "  powder, lemon juice and mix well.\n\n2)  In a bowl take lassa khoya and crumble it" +
                " well with your hands. Add flour,\n     baking soda, salt, and egg and mix well to a smooth dough. " +
                "It needs kneading\n     for at least 6-8 minutes.\n\n3)  Now make small balls of same size. " +
                "Make sure they are smooth and have\n     no cracks.\n\n4)  Heat ghee, and add balls and fry" +
                " gently and stir continuously. Make sure");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("   ghee is not very hot otherwise gulab jamun will not cook well from inside\n  " +
                    "  or will burn.\n\n5)  When gulab jamuns becomes golden, add them directly to hot syrup.\n   " +
                    "  Make sure syrup is hot (not burning hot).\n\n6)  Repeat frying process. Add all gulab jamuns " +
                    "in syrup and leave them\n     for 60 minutes.\n\n7)  Garnish with pistachios and serve.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Water 2 cups");
            //Ingredients7
            text2.setText("Sugar 1 & ½ cup");
            //Ingredients8
            text3.setText("Kewra water 1 tsp");
            //Ingredients9
            text4.setText("Cardamom powder 1/2 tsp");
            //Ingredients10
            text5.setText("Lemon juice 1 tsp");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1)  To make syrup, in a pan add water and sugar and cook until it becomes\n     " +
                    "a sticky syrup. Now turn off the flame and add kewra water, cardamom\n  " +
                    "   powder, lemon juice and mix well.\n\n2)  In a bowl take lassa khoya and crumble " +
                    "it well with your hands. Add flour,\n     baking soda, salt, and egg and mix well " +
                    "to a smooth dough. It needs kneading\n     for at least 6-8 minutes.\n\n3) " +
                    " Now make small balls of same size. Make sure they are smooth and have\n   " +
                    "  no cracks.\n\n4)  Heat ghee, and add balls and fry gently and stir continuously. Make sure");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Lassa khoya 250 grams");
            //Ingredients2
            text2.setText("Baking soda 1 pinch");
            //Ingredients3
            text3.setText("Salt 1 pinch");
            //Ingredients4
            text4.setText("Flour 1/3 cup");
            //Ingredients5
            text5.setText("Egg ½");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();
        }
    }
}
