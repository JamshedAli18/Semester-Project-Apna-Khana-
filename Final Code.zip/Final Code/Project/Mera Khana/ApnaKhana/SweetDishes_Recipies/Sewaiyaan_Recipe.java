package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Sewaiyaan_Recipe extends SweetDished_Template implements ActionListener {

    public Sewaiyaan_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\Sewaiyaan.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Sewaiyaan-Cover.jpg"));

        //Heading...............................
        heading.setText("Sewaiyaan");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("2 cup vermicelli");
        //Ingredients2
        text2.setText("1 cup condensed milk");
        //Ingredients3
        text3.setText("1 cup milk");
        //Ingredients4
        text4.setText("1/4 cup pistachios");
        //Ingredients5
        text5.setText("1/4 cup chopped almonds");

        //Steps to prepare Dish..................
        Text_area.setText("1)  Roast seviyan or vermicelli in ghee. Heat the ghee in a deep bottomed pan.\n" +
                " Add the seviyan and roast till fragrant and golden brown. Keep the flame low.\n" +
                " Once done, remove from heat and keep aside.\n\n2)   Boil milk and dissolve sugar in it.\n\n" +
                "3)  Boil milk in a pan. Add the chopped nuts and cook for 2-3 minutes. Add sugar\n" +
                " and allow it to dissolve. Now put in the condensed milk and cook on low flame till\n " +
                "it mixes well with the milk.\n\n4)  Add seviyan in the milk and cook until completely dry.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){
            Text_area.setText("5)  Finely grate the khoya and add it to the milk. Cook till the mixture thickens." +
                    "\n Add the seviyan and cook for another 5 minutes or till no liquid remains. Add\n " +
                    "the powdered cardamom and mix well. You must always add cardamom towards\n the end or " +
                    "it may lose the fragrance due to heat. Decorate with chopped nuts and\n" +
                    " serve cold or hot. Enjoy!");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1 tablespoon ghee");
            //Ingredients7
            text2.setText("50 gm khoya");
            //Ingredients8
            text3.setText("1 teaspoon powdered green cardamom");
            //Ingredients9
            text4.setText("3 tablespoon raisins");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1)  Roast seviyan or vermicelli in ghee. Heat the ghee in a deep bottomed pan.\n" +
                    " Add the seviyan and roast till fragrant and golden brown. Keep the flame low.\n" +
                    " Once done, remove from heat and keep aside.\n\n2)   Boil milk and dissolve sugar in it.\n\n" +
                    "3)  Boil milk in a pan. Add the chopped nuts and cook for 2-3 minutes. Add sugar\n" +
                    " and allow it to dissolve. Now put in the condensed milk and cook on low flame till\n " +
                    "it mixes well with the milk.\n\n4)  Add seviyan in the milk and cook until completely dry.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("2 cup vermicelli");
            //Ingredients2
            text2.setText("1 cup condensed milk");
            //Ingredients3
            text3.setText("1 cup milk");
            //Ingredients4
            text4.setText("1/4 cup pistachios");
            //Ingredients5
            text5.setText("1/4 cup chopped almonds");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {
            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();
        }
    }
}
