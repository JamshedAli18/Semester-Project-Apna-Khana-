package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HotPot_Recipe extends ChineeseFood_Template implements ActionListener {

    public HotPot_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Hot pot.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Hot-Pot-Cover.jpg"));

        //Heading...............................
        heading.setText("Hot Pot");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("450g / 1lb of lean minced beef");
        //Ingredients2
        text2.setText("1 medium onion, finely chopped");
        //Ingredients3
        text3.setText("2 medium carrots, sliced");
        //Ingredients4
        text4.setText("1 x 400g / 14 oz. tin of vegetable soup");
        //Ingredients5
        text5.setText("1 tablespoon Worcestershire sauce");

        //Steps to prepare Dish..................
        Text_area.setText("1) Freeze and partially thaw meat. " +
                "\n\n2) Wash & prepare any vegetables, mushrooms." +
                "\n\n3) Cut beef, pork, chicken into thin slices. Prepare squid." +
                " \n\n4)  Prepare marinaded fish slices Prepare fish balls."
                +"\n\n5) Prepare soup base.Prepare dipping sauce.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("1) Freeze and partially thaw meat. " +
                    "\n\n2) Wash & prepare any vegetables, mushrooms." +
                    "\n\n3) Cut beef, pork, chicken into thin slices. Prepare squid." +
                    " \n\n4)  Prepare marinaded fish slices Prepare fish balls."
                    +"\n\n5) Prepare soup base.Prepare dipping sauce.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("275ml / ½ pint of semi-skimmed milk");
            //Ingredients7
            text2.setText("4 medium potatoes peeled and thinly sliced");
            //Ingredients8
            text3.setText("Salt and pepper to taste");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1) Freeze and partially thaw meat. " +
                    "\n\n2) Wash & prepare any vegetables, mushrooms." +
                    "\n\n3) Cut beef, pork, chicken into thin slices. Prepare squid." +
                    " \n\n4)  Prepare marinaded fish slices Prepare fish balls."
                    +"\n\n5) Prepare soup base.Prepare dipping sauce.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("450g / 1lb of lean minced beef");
            //Ingredients2
            text2.setText("1 medium onion, finely chopped");
            //Ingredients3
            text3.setText("2 medium carrots, sliced");
            //Ingredients4
            text4.setText("1 x 400g / 14 oz. tin of vegetable soup");
            //Ingredients5
            text5.setText("1 tablespoon Worcestershire sauce");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}
