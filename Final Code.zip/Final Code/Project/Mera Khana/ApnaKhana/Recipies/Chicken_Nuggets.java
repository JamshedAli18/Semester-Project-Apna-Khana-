package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Chicken_Nuggets extends FastFoodTemplate implements ActionListener {
  public  Chicken_Nuggets(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\nuggets.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Nuggets-cover.jpg"));



        //Heading...............................
        heading.setText("Chicken Nuggets");

      //Ingredients sections
      text.setText("Ingredients");
      //Ingredients1
      text1.setText("1 pound boneless chicken thighs");
      //Ingredients2
      text2.setText("1 cup milk, or almond milk");
      //Ingredients3
      text3.setText("2 teaspoons apple cider vinegar");
      //Ingredients4
      text4.setText("1 teaspoon salt");
      //Ingredients5
      text5.setText("Tabasco sauce, optional");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) In a medium size bowl, mix together the milk and apple cider vinegar or lemon " +
                "\n juice and set aside for 5 minutes. " +
                "\n\n2) Add salt and Tabasco sauce to the milk mixture and whisk until incorporated." +
                "\n Pour the mixture in a large, gallon size resealable plastic" +
                "\n bag and add chicken to the mixture. Refrigerate for 1-2 hours." +
                "\n\n3) Preheat your Air Fryer at 390° F for at least 3 minutes" +
                "\n\n4) In a shallow container, mix together the breadcrumbs, flour, salt and pepper." +
                "\n\n5) Working with 2-3 pieces of chicken at a time, remove from the ");


        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

      //Previous Frame Button.........................
      PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }

//    public static void main(String[] args) {
//        Chicken_Nuggets obj = new Chicken_Nuggets();
//    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\n brine and dredge in the breadcrumb mixture. Lightly press the breading so it sticks to" +
                    "\nchicken and place in the Air Fryer basket. Repeat until the basket is filled, leaving " +
                    "\na little room between each chicken nugget. *A second batch may be necessary depend " +
                    "\non thesize of your Air Fryer basket." +
                    "\n\n6) Lightly spray the top of each piece with olive oil or avocado oil cooking " +
                    "\nspray so that the breading is lightly moist." +
                    "\n\n7) Bake at 390° F for 8 minutes then flip and coat the other side with olive oil spray. " +
                    "\n Continue to cook for an additional 4-6 minutes or until internal temperature reaches " +
                    "\n165°F." +
                    "\n\n8) Serve immediately.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 pound boneless chicken thighs");
            //Ingredients2
            text2.setText("1 cup milk, or almond milk");
            //Ingredients3
            text3.setText("2 teaspoons apple cider vinegar");
            //Ingredients4
            text4.setText("1 teaspoon salt");
            //Ingredients5
            text5.setText("Tabasco sauce, optional");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);
        }
        if(e.getSource()==Previous_btn){
            //Steps to prepare Dish..................
            Text_area.setText("\n1) In a medium size bowl, mix together the milk and apple cider vinegar or lemon " +
                    "\n juice and set aside for 5 minutes. " +
                    "\n\n2) Add salt and Tabasco sauce to the milk mixture and whisk until incorporated." +
                    "\n Pour the mixture in a large, gallon size resealable plastic" +
                    "\n bag and add chicken to the mixture. Refrigerate for 1-2 hours." +
                    "\n\n3) Preheat your Air Fryer at 390° F for at least 3 minutes" +
                    "\n\n4) In a shallow container, mix together the breadcrumbs, flour, salt and pepper." +
                    "\n\n5) Working with 2-3 pieces of chicken at a time, remove from the ");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("1 pound boneless chicken thighs");
            //Ingredients2
            text2.setText("1 cup milk, or almond milk");
            //Ingredients3
            text3.setText("2 teaspoons apple cider vinegar");
            //Ingredients4
            text4.setText("1 teaspoon salt");
            //Ingredients5
            text5.setText("Tabasco sauce, optional");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }

        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {
            frame.dispose();
            Fast_Food obj = new Fast_Food();
        }
    }
}
