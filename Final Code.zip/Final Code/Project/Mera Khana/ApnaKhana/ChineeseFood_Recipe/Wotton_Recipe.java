package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Wotton_Recipe extends ChineeseFood_Template implements ActionListener {

    public Wotton_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Wonton.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Wonton-Cover.jpg"));

        //Heading...............................
        heading.setText("Wonton");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Low-Sodium Chicken Broth");
        //Ingredients2
        text2.setText("Chicken Wontons");
        //Ingredients3
        text3.setText("Scallions , roughly chopped");
        //Ingredients4
        text4.setText("Freshly Ground Black Pepper");
        //Ingredients5
        text5.setText("Fresh ginger");

        //Steps to prepare Dish..................
        Text_area.setText("1)  In a pot add the Low-Sodium Chicken Broth (3 cups) . Once it comes up to a boil" +
                "\n add the Fresh Ginger (2 slices) , Scallions (2) and Freshly Ground Black Pepper " +
                "\n  (1/4 tsp) . Let it continue on a rolling boil for 1 minute." +
                "\n\n2) Add in the Chicken Wontons (6) and bring it back up to a boil. " +
                "\n\n3) Once the wontons are cooked, about 5 minutes, your ready to serve and enjoy!");

        //NextButton.................
        Next_btn.setText("Next");
        button.remove(Next_btn);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        button.remove(Previous_btn);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();

        }
    }
}
