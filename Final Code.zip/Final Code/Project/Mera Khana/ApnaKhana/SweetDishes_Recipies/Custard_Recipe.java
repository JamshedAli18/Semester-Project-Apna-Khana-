package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Custard_Recipe extends SweetDished_Template implements ActionListener {

    public Custard_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\Custard.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Custard-Cover.jpg"));

        //Ingredients text
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("200ml double cream");
        //Ingredients2
        text2.setText("700ml whole milk");
        //Ingredients3
        text3.setText("100g caster sugar");
        //Ingredients4
        text4.setText("3 large egg yolks");
        //Ingredients5
        text5.setText("3 tbsp cornflour");

        //Steps to prepare Dish..................
        Text_area.setText("\n\n\n 1)  Put the cream and milk into a large pan and gently bring to just below boiling\n" +
                " point. Meanwhile, in a large bowl, whisk the yolks, cornflour, sugar and vanilla." +
                "\nGradually pour the hot milk mixture onto the sugar mixture, whisking constantly.\n\n2)  " +
                "Wipe out the saucepan and pour the mixture back into it. Heat gently, stirring\n with a wooden " +
                "spoon (see Steps 1 and 2, for stirring tips) until the custard is\n thickened, but before any lumps form. " +
                "Eat hot or cold.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        //Recipies Steps Buttons.........................
        if(e.getSource()==Next_btn){
            Text_area.setText(" \n\n\n 1)  Put the cream and milk into a large pan and gently bring to just below boiling\n" +
                    " point. Meanwhile, in a large bowl, whisk the yolks, cornflour, sugar and vanilla." +
                    "\nGradually pour the hot milk mixture onto the sugar mixture, whisking constantly.\n\n2)  " +
                    "Wipe out the saucepan and pour the mixture back into it. Heat gently, stirring\n with a wooden " +
                    "spoon (see Steps 1 and 2, for stirring tips) until the custard is\n thickened, but before any lumps form. " +
                    "Eat hot or cold.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1 tsp vanilla extract");
            //Ingredients7
            text2.setText("");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){
            Text_area.setText("\n\n\n 1)  Put the cream and milk into a large pan and gently bring to just below boiling\n" +
                    " point. Meanwhile, in a large bowl, whisk the yolks, cornflour, sugar and vanilla." +
                    "\nGradually pour the hot milk mixture onto the sugar mixture, whisking constantly.\n\n2)  " +
                    "Wipe out the saucepan and pour the mixture back into it. Heat gently, stirring\n with a wooden " +
                    "spoon (see Steps 1 and 2, for stirring tips) until the custard is\n thickened, but before any lumps form. " +
                    "Eat hot or cold.");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("200ml double cream");
            //Ingredients2
            text2.setText("700ml whole milk");
            //Ingredients3
            text3.setText("100g caster sugar");
            //Ingredients4
            text4.setText("3 large egg yolks");
            //Ingredients5
            text5.setText("3 tbsp cornflour");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();

        }
    }
}


