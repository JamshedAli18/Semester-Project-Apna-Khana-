package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Jalebi_Recipe extends SweetDished_Template implements ActionListener {

    public Jalebi_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Jalebi.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Jalebi-Cover.jpg"));

        //Heading...............................
        heading.setText("Jalebi");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("3/4 cup granulated sugar");
        //Ingredients2
        text2.setText("3/4 cup water");
        //Ingredients3
        text3.setText("1 tsp lemon juice");
        //Ingredients4
        text4.setText("1 teaspoon egg yellow food colouring");
        //Ingredients5
        text5.setText("1/2 cup cake wheat flour/all purpose flour");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) Toast the saffron in a pan until fragrant. For the syrup place the water and sugar in" +
                "\na pot. Allow it to simmer on a low heat until the sugar dissolves. Simmer until it" +
                "\nreaches a one thread consistency. It will reduce to about half the amount. Add the" +
                "\nfood colouring, elachie, saffron and lemon juice to the syrup." +
                "\n\n2) To test one thread consistency, take a little syrup and allow it to cool a little or you will burn." +
                "\nPlace it between your forefinger and thumb and press and release,will form one thread." +
                "\n\n3) If your syrup becomes too thick you can add a little more water to fix it" +
                "\n\n4) For the Jalebi place the flour, bicarbonate of soda and cornflour in a bowl and mix it" +
                "");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5) Make a well in the centre and add the yogurt. Add water, a little at a time (use only " +
                    "\nwhat's required) and whisk until your form a smooth batter. Must be a little thick, but" +
                    "\nfree flowing. Whisk for at least 2-3 minutes." +
                    "\n\n6) Please do not add all of the water, the batter may become too thin. If it does" +
                    "\n become thin you can add a couple tablespoons flour to thicken it. I used about 2" +
                    "\ntablespoons short of a half cup of water" +
                    "\n\n7) Fry each side for at least one minute, on a low heat or the insides won't cook. Jalebi" +
                    "\nto drain for a few seconds on a cooling rack. Dip in warm syrup, remove and drain on " +
                    "\ncooling rack.Serve Jalebi warm or allow to completely cool before storing in an airtight" +
                    "\ncontainer. Jalebi is best made and eaten the same day");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("1/4 teaspoon bicarbonate of soda");
            //Ingredients7
            text2.setText("1 tablespoon cornflour");
            //Ingredients8
            text3.setText("3 tablespoon plain yogurt");
            //Ingredients9
            text4.setText("1/4 cup water");
            //Ingredients10
            text5.setText("vegetable oil or ghee");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n1) Toast the saffron in a pan until fragrant. For the syrup place the water and sugar in" +
                    "\na pot. Allow it to simmer on a low heat until the sugar dissolves. Simmer until it" +
                    "\nreaches a one thread consistency. It will reduce to about half the amount. Add the" +
                    "\nfood colouring, elachie, saffron and lemon juice to the syrup." +
                    "\n\n2) To test one thread consistency, take a little syrup and allow it to cool a little or you will burn." +
                    "\nPlace it between your forefinger and thumb and press and release,will form one thread." +
                    "\n\n3) If your syrup becomes too thick you can add a little more water to fix it" +
                    "\n\n4) For the Jalebi place the flour, bicarbonate of soda and cornflour in a bowl and mix it" +
                    "");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("3/4 cup granulated sugar");
            //Ingredients2
            text2.setText("3/4 cup water");
            //Ingredients3
            text3.setText("1 tsp lemon juice");
            //Ingredients4
            text4.setText("1 teaspoon egg yellow food colouring");
            //Ingredients5
            text5.setText("1/2 cup cake wheat flour/all purpose flour");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button) {
            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();
        }
    }
}
