package ApnaKhana;
import ApnaKhana.ChineeseFood_Recipe.*;
import ApnaKhana.Font_Family.Font_Family;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Chinees_Dishes  extends PreviousButton implements ActionListener {


    JFrame frame = new JFrame();
    JPanel Background_Overly = new JPanel();
    JLabel Background = new JLabel();
    JLabel Heading_Text = new JLabel();
    JButton Dumpings = new JButton();
    JButton Me_Po_Tofu = new JButton();
    JButton Fried_rice = new JButton();
    JButton Chicken_Shashlik = new JButton();
    JButton Chow_Mein = new JButton();
    JButton Spring_Rolls = new JButton();
    JButton Spicy_Tofu = new JButton();
    JButton Hot_Pot = new JButton();
    JButton Manchurian = new JButton();
    JButton Chili_Chicken = new JButton();
    JButton Wonton = new JButton();
    JButton Noodle_Soup = new JButton();
    JLabel Dumpings_Image = new JLabel();
    JLabel Me_Po_Tofu_Image = new JLabel();
    JLabel Fried_rice_Image = new JLabel();
    JLabel Chicken_Shashlik_Image = new JLabel();
    JLabel Spring_Rolls_Image = new JLabel();
    JLabel Spicy_Tofu_Image = new JLabel();
    JLabel Hot_Pot_Image = new JLabel();
    JLabel Manchurian_Image = new JLabel();
    JLabel Chili_Chicken_Image = new JLabel();
    JLabel Wonton_Image = new JLabel();
    JLabel Chow_Mein_Image = new JLabel();
    JLabel Noodle_Soup_Image = new JLabel();

        public Chinees_Dishes() {

            //Favicon
            ImageIcon favicon = new ImageIcon("\\Favicon.png");
            frame.setIconImage(favicon.getImage());

            //Background
            Background.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Background.jpg"));
            Background.setBounds(0, 0, 1270, 720);

            //Background Overly
            Background_Overly.setBackground(new Color((float) 0, (float) 0, (float) 0, (float) 0.7));
            Background_Overly.setBounds(0, 0, 1270, 720);

            //Menu Setting
            Heading_Text.setText("Menu");
            Heading_Text.setFont(Magrib);
            Heading_Text.setForeground(Color.black);
            Heading_Text.setBounds(520, 20, 600, 100);

            //Dumpings Text Section
            Dumpings.setText("Dumpings");
            Dumpings.setFont(Asap);
            Dumpings.setForeground(Color.BLACK);
            Dumpings.setBounds(-25, 140, 290, 150);
            Dumpings.setOpaque(false);
            Dumpings.setContentAreaFilled(false);
            Dumpings.setBorderPainted(false);
            Dumpings.setFocusable(false);

            //Dumpings Image Section
            Dumpings_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Dumpings.png"));
            Dumpings_Image.setBounds(300, 150, 160, 130);
            Dumpings_Image.setOpaque(false);

            //Me_Po_Tofu Text Section
            Me_Po_Tofu.setText("Me Po Tofu");
            Me_Po_Tofu.setFont(Asap);
            Me_Po_Tofu.setForeground(Color.BLACK);
            Me_Po_Tofu.setBounds(-16, 270, 290, 150);
            Me_Po_Tofu.setOpaque(false);
            Me_Po_Tofu.setContentAreaFilled(false);
            Me_Po_Tofu.setBorderPainted(false);
            Me_Po_Tofu.setFocusable(false);

            //Me Po Tofu Image Section
            Me_Po_Tofu_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Me Po Tofu.png"));
            Me_Po_Tofu_Image.setBounds(300, 280, 160, 130);
            Me_Po_Tofu_Image.setOpaque(false);

            //Fried_rice Text Section
            Fried_rice.setText("Fried Rice");
            Fried_rice.setFont(Asap);
            Fried_rice.setForeground(Color.BLACK);
            Fried_rice.setBounds(5, 400, 230, 150);
            Fried_rice.setOpaque(false);
            Fried_rice.setContentAreaFilled(false);
            Fried_rice.setBorderPainted(false);
            Fried_rice.setFocusable(false);

            //Fried_rice Image Section
            Fried_rice_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Fried Rice.png"));
            Fried_rice_Image.setBounds(300, 410, 190, 130);
            Fried_rice_Image.setOpaque(false);

            //Chicken_Shashlik Text Section
            Chicken_Shashlik.setText("Shashlik");
            Chicken_Shashlik.setFont(Asap);
            Chicken_Shashlik.setForeground(Color.BLACK);
            Chicken_Shashlik.setBounds(-40, 530, 290, 150);
            Chicken_Shashlik.setOpaque(false);
            Chicken_Shashlik.setContentAreaFilled(false);
            Chicken_Shashlik.setBorderPainted(false);
            Chicken_Shashlik.setFocusable(false);

            //Chicken_Shashlik Image Section
            Chicken_Shashlik_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Shashlik.png"));
            Chicken_Shashlik_Image.setBounds(300, 540, 160, 130);
            Chicken_Shashlik_Image.setOpaque(false);

            //Chow_Mein Text Section
            Chow_Mein.setText("Chow Mein");
            Chow_Mein.setFont(Asap);
            Chow_Mein.setForeground(Color.BLACK);
            Chow_Mein.setBounds(390, 140, 290, 150);
            Chow_Mein.setOpaque(false);
            Chow_Mein.setContentAreaFilled(false);
            Chow_Mein.setBorderPainted(false);
            Chow_Mein.setFocusable(false);

            //Chow_Mein Image Section
            Chow_Mein_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Chow Mein.png"));
            Chow_Mein_Image.setBounds(700, 150, 160, 130);
            Chow_Mein_Image.setOpaque(false);

            //Spring_Rolls Text Section
            Spring_Rolls.setText("Spring Rolls");
            Spring_Rolls.setFont(Asap);
            Spring_Rolls.setForeground(Color.BLACK);
            Spring_Rolls.setBounds(395, 270, 300, 150);
            Spring_Rolls.setOpaque(false);
            Spring_Rolls.setContentAreaFilled(false);
            Spring_Rolls.setBorderPainted(false);
            Spring_Rolls.setFocusable(false);

            //Spring_Rolls Image Section
            Spring_Rolls_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Spring Rolls.png"));
            Spring_Rolls_Image.setBounds(700, 280, 160, 130);
            Spring_Rolls_Image.setOpaque(false);

            //Spicy Tofu Text Section
            Spicy_Tofu.setText("Spicy Tofu");
            Spicy_Tofu.setFont(Asap);
            Spicy_Tofu.setForeground(Color.BLACK);
            Spicy_Tofu.setBounds(420, 400, 230, 150);
            Spicy_Tofu.setOpaque(false);
            Spicy_Tofu.setContentAreaFilled(false);
            Spicy_Tofu.setBorderPainted(false);
            Spicy_Tofu.setFocusable(false);

            //Spicy_Tofu Image Section
            Spicy_Tofu_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Spicy Tofu.png"));
            Spicy_Tofu_Image.setBounds(700, 410, 160, 130);
            Spicy_Tofu_Image.setOpaque(false);

            //Hot_Pot Tukre Text Section
            Hot_Pot.setText("Hot Pot");
            Hot_Pot.setFont(Asap);
            Hot_Pot.setForeground(Color.BLACK);
            Hot_Pot.setBounds(365, 530, 290, 150);
            Hot_Pot.setOpaque(false);
            Hot_Pot.setContentAreaFilled(false);
            Hot_Pot.setBorderPainted(false);
            Hot_Pot.setFocusable(false);

            //Hot_Pot Image Section
            Hot_Pot_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Hot Pots.png"));
            Hot_Pot_Image.setBounds(700, 540, 160, 130);
            Hot_Pot_Image.setOpaque(false);

            //Manchurian Text Section
            Manchurian.setText("Manchurian");
            Manchurian.setFont(Asap);
            Manchurian.setForeground(Color.BLACK);
            Manchurian.setBounds(790, 140, 290, 150);
            Manchurian.setOpaque(false);
            Manchurian.setContentAreaFilled(false);
            Manchurian.setBorderPainted(false);
            Manchurian.setFocusable(false);

            //Manchurian Image Section
            Manchurian_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Manchurian.png"));
            Manchurian_Image.setBounds(1100, 150, 100, 130);
            Manchurian_Image.setOpaque(false);

            //Chili_Chicken Text Section
            Chili_Chicken.setText("Chili Chicken");
            Chili_Chicken.setFont(Asap);
            Chili_Chicken.setForeground(Color.BLACK);
            Chili_Chicken.setBounds(805, 270, 290, 150);
            Chili_Chicken.setOpaque(false);
            Chili_Chicken.setContentAreaFilled(false);
            Chili_Chicken.setBorderPainted(false);
            Chili_Chicken.setFocusable(false);

            //Chili_Chicken Image Section
            Chili_Chicken_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Chili Chicken.png"));
            Chili_Chicken_Image.setBounds(1100, 280, 100, 130);
            Chili_Chicken_Image.setOpaque(false);

            //Wonton Text Section
            Wonton.setText("Wonton");
            Wonton.setFont(Asap);
            Wonton.setForeground(Color.BLACK);
            Wonton.setBounds(795, 400, 230, 150);
            Wonton.setOpaque(false);
            Wonton.setContentAreaFilled(false);
            Wonton.setBorderPainted(false);
            Wonton.setFocusable(false);

            //Wonton Image Section
            Wonton_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Wondon.png"));
            Wonton_Image.setBounds(1100, 410, 160, 130);
            Wonton_Image.setOpaque(false);

            //Noodle_Soup Text Section
            Noodle_Soup.setText("Noodle Soup");
            Noodle_Soup.setFont(Asap);
            Noodle_Soup.setForeground(Color.BLACK);
            Noodle_Soup.setBounds(805, 530, 290, 150);
            Noodle_Soup.setOpaque(false);
            Noodle_Soup.setContentAreaFilled(false);
            Noodle_Soup.setBorderPainted(false);
            Noodle_Soup.setFocusable(false);

            //Sheer Khurma Image Section
            Noodle_Soup_Image.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Chinease\\Noodle Soup.png"));
            Noodle_Soup_Image.setBounds(1100, 540, 160, 130);
            Noodle_Soup_Image.setOpaque(false);

            //Adding Buttons Functionalties......................
            Dumpings.addActionListener(this);
            Me_Po_Tofu.addActionListener(this);
            Fried_rice.addActionListener(this);
            Chicken_Shashlik.addActionListener(this);
            Chow_Mein.addActionListener(this);
            Spring_Rolls.addActionListener(this);
            Spicy_Tofu.addActionListener(this);
            Hot_Pot.addActionListener(this);
            Manchurian.addActionListener(this);
            Chili_Chicken.addActionListener(this);
            Wonton.addActionListener(this);
            Noodle_Soup.addActionListener(this);

            //Button for returning to previous frame
            Previous_frame.addActionListener(this);

            // Adding in Frame Section
            frame.setVisible(true);
            frame.setLayout(null);
            frame.add(Heading_Text);
            frame.add(Dumpings);
            frame.add(Dumpings_Image);
            frame.add(Me_Po_Tofu);
            frame.add(Me_Po_Tofu_Image);
            frame.add(Fried_rice);
            frame.add(Fried_rice_Image);
            frame.add(Chow_Mein);
            frame.add(Chow_Mein_Image);
            frame.add(Spring_Rolls);
            frame.add(Spring_Rolls_Image);
            frame.add(Spicy_Tofu);
            frame.add(Spicy_Tofu_Image);
            frame.add(Hot_Pot);
            frame.add(Hot_Pot_Image);
            frame.add(Manchurian);
            frame.add(Manchurian_Image);
            frame.add(Noodle_Soup);
            frame.add(Noodle_Soup_Image);
            frame.add(Chicken_Shashlik);
            frame.add(Chicken_Shashlik_Image);
            frame.add(Wonton);
            frame.add(Chili_Chicken);
            frame.add(Chili_Chicken_Image);
            frame.add(Wonton_Image);
            frame.add(Previous_frame);
            frame.add(Background);
            frame.setSize(1270, 720);

        }
    @Override
    public void actionPerformed(ActionEvent e){

        //giving instructions.....................
        if(e.getSource()==Dumpings){

            frame.dispose();
            Dumping_Recipe obj = new Dumping_Recipe();

        }else if(e.getSource()==Me_Po_Tofu){

            frame.dispose();
            MePoTofu_Recipe obj = new MePoTofu_Recipe();

        }else if(e.getSource()==Fried_rice){

            frame.dispose();
            FriedRice_Recipe obj = new FriedRice_Recipe();

        }else if(e.getSource()==Chicken_Shashlik){

            frame.dispose();
            Shashlik_Recipe obj = new Shashlik_Recipe();

        }else if(e.getSource()==Chow_Mein){

            frame.dispose();
            ChowMein_Recipe obj = new ChowMein_Recipe();

        }else if(e.getSource()==Spring_Rolls){

            frame.dispose();
            SpringRoll_Recipe obj = new SpringRoll_Recipe();

        }else if(e.getSource()==Spicy_Tofu){

            frame.dispose();
            SpicyTofu_Recipe obj = new SpicyTofu_Recipe();

        }else if(e.getSource()==Hot_Pot){

            frame.dispose();
            HotPot_Recipe obj = new HotPot_Recipe();

        }else if(e.getSource()==Manchurian){

            frame.dispose();
            Manchurian_Recipe obj = new Manchurian_Recipe();

        }else if(e.getSource()==Chili_Chicken){

            frame.dispose();
            ChilliChicken_Recipe obj = new ChilliChicken_Recipe();

        }else if(e.getSource()==Wonton){

            frame.dispose();
            Wotton_Recipe obj = new Wotton_Recipe();

        }else if(e.getSource()==Noodle_Soup){

            frame.dispose();
            NoodleSoup_Recipe obj = new NoodleSoup_Recipe();

        }else if(e.getSource()==Previous_frame){

            frame.dispose();
            Categories Main_Page = new Categories();

        }
    }
}
