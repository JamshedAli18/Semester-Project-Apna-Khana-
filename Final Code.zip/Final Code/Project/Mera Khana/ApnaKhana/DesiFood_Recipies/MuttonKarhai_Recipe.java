package ApnaKhana.DesiFood_Recipies;

import ApnaKhana.Desi_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MuttonKarhai_Recipe extends DesiFood_Template implements ActionListener {

    public MuttonKarhai_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("\\Mutton Karhai.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\Mutton-Karhai-Cover.jpg"));

        //Heading...............................
        heading.setText("Mutton Karhai");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Mutton boneless ½ kg");
        //Ingredients2
        text2.setText("Garlic paste 2tbsp");
        //Ingredients3
        text3.setText("Ginger paste 1tbsp");
        //Ingredients4
        text4.setText("Tomatoes 2 cups");
        //Ingredients5
        text5.setText("Salt 1tsp");

        //Steps to prepare Dish..................
        Text_area.setText("1. Boil ½ kg of mutton in 2tbsp of ginger and 1tbsp of garlic paste" +
                "\n and then let the water dries.\n" +
                "\n2. Heat oil in pan add 1tbsp of chopped garlic in pan and sauté with mutton.\n" +
                "\n3. Put few curry leaves in other pan and let it sauté\n" +
                "\n4. Add 1tbsp of ginger paste, 1 tbsp of garlic paste, 1 tsp of salt, 1 tsp of" +
                "\nred chili powder, 1-1/2 tsp of garam masala and in last put 1/2 cup of sesame" +
                "\n seeds and 2 cups of tomato paste. Allow to sauté with curry leaves.\n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n5. Now add ½ kg of mutton in mixture and cook nicely\n" +
                    "\n6. When cooked then add ginger strips, green chilies and fresh green coriander.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Red chili powder 1tsp");
            //Ingredients2
            text2.setText("Garam masala 1-1/2 tsp");
            //Ingredients3
            text3.setText("Sesame seeds ½ cup");
            //Ingredients4
            text4.setText("Oil as required");
            //Ingredients5
            text5.setText("Curry leaves few");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("1. Boil ½ kg of mutton in 2tbsp of ginger and 1tbsp of garlic paste" +
                    "\n and then let the water dries.\n" +
                    "\n2. Heat oil in pan add 1tbsp of chopped garlic in pan and sauté with mutton.\n" +
                    "\n3. Put few curry leaves in other pan and let it sauté\n" +
                    "\n4. Add 1tbsp of ginger paste, 1 tbsp of garlic paste, 1 tsp of salt, 1 tsp of" +
                    "\nred chili powder, 1-1/2 tsp of garam masala and in last put 1/2 cup of sesame" +
                    "\n seeds and 2 cups of tomato paste. Allow to sauté with curry leaves.\n");

            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Mutton boneless ½ kg");
            //Ingredients2
            text2.setText("Garlic paste 2tbsp");
            //Ingredients3
            text3.setText("Ginger paste 1tbsp");
            //Ingredients4
            text4.setText("Tomatoes 2 cups");
            //Ingredients5
            text5.setText("Salt 1tsp");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Desi_Food obj = new Desi_Food();

        }
    }
}
