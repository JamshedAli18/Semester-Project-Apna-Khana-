package ApnaKhana.Recipies;

import ApnaKhana.Fast_Food;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Roll_Recipe extends FastFoodTemplate implements ActionListener {

    public Roll_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\roll.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("C:\\Users\\University\\Desktop\\Project\\Mera Khana\\Pictures\\Fast Food Recipies Pictureas\\Roll-Cover.jpg"));

        //Heading...............................
        heading.setText("Roll");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("10 Slices sandwich bread");
        //Ingredients2
        text2.setText("10 Sausage links, cooked");
        //Ingredients3
        text3.setText("3 Eggs");
        //Ingredients4
        text4.setText("1 Tablespoon milk");
        //Ingredients5
        text5.setText("½ Teaspoon cinnamon");

        //Steps to prepare Dish..................
        Text_area.setText("\n1) Cut off the crust of each piece of bread and then roll" +
                "\nthe bread thin with a rolling pin" +
                "\n\n2)Place cooked and warm sausage at the edge of one side of the" +
                "\nbread and roll it up tightly. Repeat and set aside." +
                "\n\n3)In a bowl, combine eggs, milk, cinnamon, and vanilla." +
                "\nWhisk until well incorporated." +
                "\n");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("\n\n\n4) Melt 1 tablespoon butter in a large skillet. Then dip each roll-up in egg " +
                    "\n , and cook on all sides until golden brown. Add more butter when needed." +
                    "\n\n5)Sprinkle with confectioners' sugar and serve with maple syrup." );

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("½ Teaspoon vanilla extract");
            //Ingredients7
            text2.setText("2 Tablespoons butter, divided");
            //Ingredients8
            text3.setText("");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            butoon.remove(Next_btn);
            butoon.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            //Steps to prepare Dish..................
            Text_area.setText("\n1) Cut off the crust of each piece of bread and then roll" +
                    "\nthe bread thin with a rolling pin" +
                    "\n\n2)Place cooked and warm sausage at the edge of one side of the" +
                    "\nbread and roll it up tightly. Repeat and set aside." +
                    "\n\n3)In a bowl, combine eggs, milk, cinnamon, and vanilla." +
                    "\nWhisk until well incorporated." +
                    "\n");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("10 Slices sandwich bread");
            //Ingredients2
            text2.setText("10 Sausage links, cooked");
            //Ingredients3
            text3.setText("3 Eggs");
            //Ingredients4
            text4.setText("1 Tablespoon milk");
            //Ingredients5
            text5.setText("½ Teaspoon cinnamon");

            butoon.add(Next_btn);
            butoon.remove(Previous_btn);
        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Fast_Food obj = new Fast_Food();

        }
    }
}

