package ApnaKhana.ChineeseFood_Recipe;

import ApnaKhana.Chinees_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChowMein_Recipe extends ChineeseFood_Template implements ActionListener {
    public ChowMein_Recipe(){

        //small Image......................
        label2.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Chow mein.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("D:\\JAMSHED ALI\\Final Code\\Project\\Mera Khana\\Pictures\\Pictures of chiness Dishes\\Chow-Mein Cover.jpg"));

        //Heading...............................
        heading.setText("Chow Mein");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Oyster sauce 1 tbs");
        //Ingredients2
        text2.setText("Soy sauce 2 tbs");
        //Ingredients3
        text3.setText("Sesame oil 1 tsp");
        //Ingredients4
        text4.setText("Cheeni (Sugar) 1 tbs (optional)");
        //Ingredients5
        text5.setText("Kali mirch powder (Black pepper powder) 1 tsp");

        //Steps to prepare Dish..................
        Text_area.setText("1) Pound chicken breast with mallet until 1/2-inch thick,then cut it into pieces" +
                " \nas required.\n\n2) Heat butter in a pan and dip chicken pieces, one at a time.\n\n3)" +
                " Then roll chicken in cracker meal till each piece is fully coated. \n\n" +
                "4)  Bake the coated pieces for 10 minutes in center of oven until chicken is turned crisp.");


        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //Previous Frame Button.........................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==Next_btn){

            Text_area.setText("1) Pound chicken breast with mallet until 1/2-inch thick,then cut it into pieces" +
                    " \nas required.\n\n2) Heat butter in a pan and dip chicken pieces, one at a time.\n\n3)" +
                    " Then roll chicken in cracker meal till each piece is fully coated. \n\n" +
                    "4)  Bake the coated pieces for 10 minutes in center of oven until chicken is turned crisp.");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Safed mirch powder (White pepper powder) ½ tsp");
            //Ingredients7
            text2.setText("Corn flour 2 tbs");
            //Ingredients8
            text3.setText("Chicken boneless cut in strips 250 gms");
            //Ingredients9
            text4.setText("Chow mein sauce 1 tbs");
            //Ingredients10
            text5.setText("Oil 2 tbs");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){
            Text_area.setText("1) Pound chicken breast with mallet until 1/2-inch thick,then cut it into pieces" +
                    " \nas required.\n\n2) Heat butter in a pan and dip chicken pieces, one at a time.\n\n3)" +
                    " Then roll chicken in cracker meal till each piece is fully coated. \n\n" +
                    "4)  Bake the coated pieces for 10 minutes in center of oven until chicken is turned crisp.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Oyster sauce 1 tbs");
            //Ingredients2
            text2.setText("Soy sauce 2 tbs");
            //Ingredients3
            text3.setText("Sesame oil 1 tsp");
            //Ingredients4
            text4.setText("Cheeni (Sugar) 1 tbs (optional)");
            //Ingredients5
            text5.setText("Kali mirch powder (Black pepper powder) 1 tsp");

            button.add(Next_btn);
            button.remove(Previous_btn);

        }
        //Previous Frame Button
        if (e.getSource() == PreviousFrame_Button) {

            frame.dispose();
            Chinees_Dishes obj = new Chinees_Dishes();
        }
    }
}

