package ApnaKhana.SweetDishes_Recipies;

import ApnaKhana.Sweet_Dishes;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SujiHalwa_Recipe extends SweetDished_Template implements ActionListener {

    public SujiHalwa_Recipe(){
        //small Image......................
        label2.setIcon(new ImageIcon("\\SujiHalwa.png"));

        //Large Image.............................
        label1.setIcon(new ImageIcon("\\SujiHalwa-Cover.jpg"));

        //Heading...............................
        heading.setText("Suji ka Halwa");

        //Ingredients sections
        text.setText("Ingredients");
        //Ingredients1
        text1.setText("Desi ghee ½ cup (solid form)");
        //Ingredients2
        text2.setText("Choti elaichi (green cardamom) 3-4");
        //Ingredients3
        text3.setText("Sooji (semolina) ¾ cup");
        //Ingredients4
        text4.setText("Cheeni (sugar) 1 & ¼ cup");
        //Ingredients5
        text5.setText("Pani (water) 3 cups");

        //Steps to prepare Dish..................
        Text_area.setText("\n\n1)  In wok, heat ghee and add green cardamom, sauté for a minute.\n\n" +
                "2)  Add semolina and roast on medium low flame until color change and fragrant.\n\n" +
                "3)  Add sugar and give it a good mix.\n\n4)  Add water and food color, mix well, cover " +
                "and cook on medium low flame for 3-4 minutes.\n\n5)  Add kewra essence and mix it.");

        //NextButton.................
        Next_btn.setText("Next");
        Next_btn.addActionListener(this);

        //PreviousButton..............
        Previous_btn.setText("Previous");
        Previous_btn.addActionListener(this);

        //PreviousFrame Button .....................
        PreviousFrame_Button.addActionListener(this);

        //Frame Display properties.................
        frame.setSize(1270, 720);
        frame.setResizable(false);
        frame.setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Next_btn){
            Text_area.setText("\n\n6)  Garnish with dry fruits.\n\n7)  Suji ka halwa is ready. ");

            //Ingredients..........................
            text.setText("Ingredients");
            //Ingredients6
            text1.setText("Food color (Zarda ka rang)");
            //Ingredients7
            text2.setText("Kewra essence ½ tsp");
            //Ingredients8
            text3.setText("Dry fruits");
            //Ingredients9
            text4.setText("");
            //Ingredients10
            text5.setText("");

            button.remove(Next_btn);
            button.add(Previous_btn);

        }else if(e.getSource()==Previous_btn){

            Text_area.setText("\n\n1)  In wok, heat ghee and add green cardamom, sauté for a minute.\n\n" +
                    "2)  Add semolina and roast on medium low flame until color change and fragrant.\n\n" +
                    "3)  Add sugar and give it a good mix.\n\n4)  Add water and food color, mix well, cover " +
                    "and cook on medium low flame for 3-4 minutes.\n\n5)  Add kewra essence and mix it.");

            //Ingredients sections
            text.setText("Ingredients");
            //Ingredients1
            text1.setText("Desi ghee ½ cup (solid form)");
            //Ingredients2
            text2.setText("Choti elaichi (green cardamom) 3-4");
            //Ingredients3
            text3.setText("Sooji (semolina) ¾ cup");
            //Ingredients4
            text4.setText("Cheeni (sugar) 1 & ¼ cup");
            //Ingredients5
            text5.setText("Pani (water) 3 cups");

            button.add(Next_btn);
            button.remove(Previous_btn);
        }
        //Previous Frame Button
        if(e.getSource()==PreviousFrame_Button){

            frame.dispose();
            Sweet_Dishes obj = new Sweet_Dishes();

        }
    }
}
